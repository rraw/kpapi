$(document).ready(function(){

	var base_url = "http://localhost/kpFAQ/";
	
	$(".toggle_container").hide();

	$("div.trigger").toggle(function(){
		$(this).addClass("active"); 
		}, function () {
		$(this).removeClass("active");
	});

	$(".trigger-span").toggle(function(){
		$(this).addClass("active-span"); 
		}, function () {
		$(this).removeClass("active-span");
	});


	$(".trigger-span").click(function(){
		$(this).parent().next(".toggle_container").slideToggle("slow,");
	});

	// click function trigger
	$("div.trigger.a a").click(function(){
		$('#article-content').
        load(base_url+'index.php/cms/display_category_content/'+this.id);
	});
	
	$("div.trigger.b a").click(function(){
		  $('#article-content').
           load(base_url+'index.php/cms/display_category_content/'+this.id);
	});

	$(".sub-btn").hide();

	$(".button-group#add-content").hover(
		function()
		{
    		$(".sub-btn").slideToggle("fast");
    	}

		,function()
		{
			$(".sub-btn").slideToggle("fast");
		}
	);	

});