$(document).ready(function() 
{
    var base_url = "http://localhost/kpFAQ";

	// function for displaying category selected
    $(".category-tag").click(function()
    {
    	var category_id = $(this).attr('id');
    	var category_name =$(this).next().attr('id');
    	category_name = category_name.split(" ").join("-");
        category_name = category_name.replace(",","");
		var url = base_url+"/index.php/category/index/"+category_id+"/"+category_name;
		$(location).attr('href',url);

    });

    // function for displaying article selected
    $(".article-tag").click(function()
    {
    	var article_id = $(this).attr('id');
    	var article_name = $(this).next().attr('id');
    	article_name = article_name.split(" ").join("-");
        article_name = article_name.split(",").join("");
        article_name = article_name.split("?").join("");

        url = base_url+"/index.php/article/add_nview_article/"+article_id

        $.post(url,
            function()
            {
                var url = base_url+"/index.php/article/index/"+article_id+"/"+article_name;
                window.location.replace(url);
            });;

    });

    $(".tag-list").click(function(){
        var tag_id = $(this).attr('id');
        var tag_name =$(this).next().attr('id');
        // convert space into -
        var tag_name =tag_name.split(" ").join("-");

        // alert(tag_id);
        // alert(tag_name);
        var url = base_url+"/index.php/tag/index/"+tag_id+"/"+tag_name;
            $(location).attr('href',url);
    });
});