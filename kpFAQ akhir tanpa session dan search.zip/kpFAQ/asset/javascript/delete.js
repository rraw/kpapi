$(document).ready(function() {
     var base_url = "http://localhost/kpFAQ/";

    $(".deletearticle").click(function()
    {
    	var article_id = $(this).prop("id");
    	var article_name = $(this).parents(".table_row").children(".article_name").html();

      	if(confirm("Anda akan menghapus artikel : " + article_name +". Anda yakin?"))
		{
    		$.post(base_url+"index.php/cms_delete/delete_article/" + article_id, function(data)
            {
                alert(article_name + " berhasil dihapus.");
                window.location.replace(base_url+"index.php/cms");
            })
		}
		else
		{
    		//do nothing
		}
    });

    $("#deletecategory").click(function()
    {
        var category_id = $("#category_id").val();
        var category_name = $("#category_name").val();

        if(confirm("Anda akan menghapus kategori : " + category_name + ". Anda yakin?"))
        {
            $.post(base_url+"index.php/cms_delete/delete_category/" + category_id, function(data)
            {
                alert(category_name + " berhasil dihapus.");
                window.location.replace(base_url+"index.php/cms");
            });
        }
        else
        {
            //do nothing
        }
    });

});