<div class="container category">  



<?php
		echo "<h1>"; 
		// Printing category name
		$string = explode("-", $category_name);
		foreach ($string as $key) {
			# code...
			echo $key;
			echo " ";
		}

		echo "</h1>";

		echo "<p>";
		foreach ($category_content as $row) 
		{
			echo $row->category_content;
			# code...
		}
		echo "</p>";
		

		echo "<h4>";
		echo "Artikel Terkait";
		echo "</h4>";
	// Printing every article in selected category 
	foreach ($article_from_category as $row) 
	{
		# code...
?>
	<div class ="article-title article-tag" id="<?php echo $row->article_id; ?>">
		<h4><?php  echo $row->article_name;?></h4>
	</div>
<?php  
	echo "<div id=\"".$row->article_name."\" style=\"hidden\"></div>";

?>


<?php
	}

?>
</div>