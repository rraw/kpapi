<div class="main">

<h2>Edit Category Rank</h2>

<form action="http://localhost/kpFAQ/index.php/cms/submit_rank" method="POST">
<table class="edit-rank">
<thead>
	<tr>
		<th>Category Name</th>
		<th>Edit Rank</th>
	</tr>
</thead>

<?php 
	//bikin input text
	foreach ($category as $row) {
		echo "<tr>";
		echo "<td>";
		echo $row->category_name;
		echo "</td>";
		echo "<td>";
		echo "<input type='text' name='cat". $row->category_id ."' value='". $row->category_rank ."'><br>";
		echo "</td>";
		echo "</tr>";
	}
?>
<tr>
	<td class="invincible"></td>
	<td class="invincible">
		<button type="submit" value="Save" class="submit">Save</button>
	</td>
</tr>
</table>
</form>
</div>
</body>

</html>