<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class navigation_bar_model extends CI_Model 
{

	function get_category()
	{
		$q = $this->db->query("SELECT * FROM category WHERE category_status>='0' ORDER BY category_rank");
		return $q->result();
	}

	function get_article_by_categoryid($category_id)
	{
		$query = "SELECT * FROM article WHERE article_status>='0' AND category_id="."'".$category_id."'";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_categoryid_by_articleid($article_id)
	{
		$query = "SELECT category_id FROM article WHERE article_status >='0' AND article_id=".$article_id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	//g ada yang make
	function get_active_article_by_categoryid($category_id)
	{
		$query = "SELECT * FROM article WHERE article_status='1' AND category_id="."'".$category_id."'";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_active_category()
	{
		$q = $this->db->query("SELECT * FROM category WHERE category_status='1' ORDER BY category_rank");
		return $q->result();
	}
}