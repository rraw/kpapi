<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/**
* 
*/
class Article extends CI_Controller
{
	function index($article_id = NULL,$article_name = NULL)
	{
		$this->display_header();
		$this->display_content($article_id,$article_name);
		$this->display_footer();
	}

	function display_header()
	{
		$this->load->view('header');
	}

	function display_content($article_id = NULL, $article_name = NULL)
	{
		$this->load->model('faq_model');
		$data['article'] =$this->faq_model->get_article_by_id($article_id);
		// $data['article_name'] = $article_name;
		$data['tags'] = $this->faq_model->get_tag_by_article_id($article_id);
		$this->load->view('article_view',$data);
	}

	function display_footer()
	{
		$this->load->view('footer');

	}

	function add_nview_article($article_id = NULL)
	{
		$this->load->model('faq_model');
		$this->faq_model->add_nview_by_article_id($article_id);
	}
}

?>