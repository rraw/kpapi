<?php  

/**
* Class tag display controller
*/
class Tag extends CI_Controller
{
	
	function index($tag_id = NULL ,$tag_name = NULL)
	{
		$this->display_header();
		$this->display_content($tag_id,$tag_name);
		$this->display_footer();
	}

	function display_header()
	{
		$this->load->view('header');
	}

	function display_content($tag_id = NULL ,$tag_name = NULL)
	{
		$this->load->model('faq_model');
		$data['article_list'] = $this->faq_model->get_article_by_tag_id($tag_id);
		$data['tag_name'] = $tag_name;
		$this->load->view('tag_view',$data);
	}

	function display_footer()
	{
		$this->load->view('footer');
	}



}

?>