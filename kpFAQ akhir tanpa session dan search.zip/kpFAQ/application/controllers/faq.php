<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/**
* Main Controller
*/
class Faq extends CI_Controller
{
	
	function index()
	{
		// Display view
		$this->display_header();
		$this->display_home();
		$this->display_footer();
	}

	function display_header()
	{
		$this->load->view('header');
	}

	function display_content()
	{
		$this->load->view('main_content');
	}

	// fungsi untuk menampilkan konten utama pada halaman home
	function display_home()
	{
		// Load model
		$this->load->model('faq_model');

		// get all category
		$data['category'] = $this->faq_model->get_all_active_category();
		$data['tag_list'] = $this->faq_model->get_all_active_tag();
		foreach ($data['category'] as $category) {
			$data['recomended_article'][$category->category_id] = $this->faq_model->get_5_recomended_article_by_categoryid($category->category_id);
			$data['most_seen_article'][$category->category_id] = $this->faq_model->get_3_most_seen_article_3month_by_categoryid($category->category_id);
			$data['latest_article'][$category->category_id] = $this->faq_model->get_3_latest_article_by_categoryid($category->category_id);
		}

		// menampilkan body dengan data hasil query
		$this->load->view('home',$data);
	}

	function display_footer()
	{
		$this->load->view('footer');
	}


	function display_all_article_in_category($category_id = NULL)
	{
		$this->load->model('faq_model');
		$data['article_from_category'] = $this->faq_model->get_article_by_categoryid($category_id);
		$this->load->view('category_view',$data);
	}

}



?>