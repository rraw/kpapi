<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* faq model
*/
class faq_model extends CI_Model
{
	function get_all_active_category()
	{
		$query = "SELECT * FROM category WHERE category_status > 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_article_by_categoryid($category_id)
	{
		$query = "SELECT * FROM article WHERE category_id='".$category_id."' AND article_status > 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_category_content_by_id($category_id)
	{
		$query = "SELECT category_content FROM category WHERE category_id='".$category_id."' AND category_status > 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_article_by_id($article_id)
	{
		$query = "SELECT * FROM article WHERE article_id='".$article_id."' AND article_status > 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_article_by_tag_id($tag_id)
	{
		$query ="SELECT * FROM article INNER JOIN mapping on article.article_id = mapping.article_id WHERE tag_id ='".$tag_id."' AND article_status > 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_5_recomended_article_by_categoryid($category_id)
	{
		$query = "SELECT article_id, article_name FROM article WHERE category_id='".$category_id."' AND article_status = 127 ";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_3_most_seen_article_3month_by_categoryid($category_id)
	{
		$query = "SELECT article.article_id, article.article_name, COUNT(nview_id) AS seen_by FROM nview LEFT JOIN article ON article.article_id = nview.article_id WHERE article.category_id = ".$category_id." AND article.article_status > 0 AND EXTRACT(MONTH from CURDATE())- EXTRACT(MONTH from nview.nview_readdate)<=3 GROUP BY article_id ORDER BY seen_by DESC LIMIT 3";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_3_latest_article_by_categoryid($category_id)
	{
		$query = "SELECT article_id,article_name FROM article WHERE article_status > 0 ORDER BY article_update LIMIT 3";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_all_active_tag()
	{
		$query="SELECT tag.tag_id, tag.tag_name FROM tag INNER JOIN mapping ON tag.tag_id = mapping.tag_id WHERE mapping.mapping_status > 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function get_tag_by_article_id($article_id)
	{
		$query ="SELECT tag.tag_name,tag.tag_id FROM tag INNER JOIN mapping ON tag.tag_id = mapping.tag_id WHERE article_id = '".$article_id."'";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
	function add_nview_by_article_id($article_id)
	{
		$query = "INSERT INTO nview VALUES('','".$article_id."','".date('Y-m-d H:i:s')."')";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
}

?>