<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Content_model extends CI_Model 
{

	function get_active_article_description($id)
	{
		$query = "SELECT * FROM article WHERE article_id =".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_content($id)
	{
		$query = "SELECT * FROM article WHERE article_id =".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_category_content($category_id)
	{
		$query = "SELECT category_status,category_content,category_name,category_id FROM category WHERE category_id =".$category_id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_tags_of_article($id)
	{
		$q = "SELECT tag_name FROM tag INNER JOIN mapping ON tag.tag_id=mapping.tag_id WHERE mapping_status>=0 AND article_id=".$id;
		$result = $this->db->query($q);
		return $result->result_array();
	}

	function update_entry_content($data){
		$this->db->where('category_id',$data['category_id']);
		$this->db->update('category',$data);
	}

	function update_rank($id, $rank)
	{
		$query = "UPDATE category SET category_rank = '". $rank."' WHERE category_id='". $id . "'";
		$query_result = $this->db->query($query);
	}
}