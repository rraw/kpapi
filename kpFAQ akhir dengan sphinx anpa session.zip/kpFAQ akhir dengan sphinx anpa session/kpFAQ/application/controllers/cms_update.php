<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CMS_update extends CI_Controller
{
	//proses database dari masing2 perintah
	public function update_article()
	{
		//load model dan set timezone
		$this->load->model('article_model'); date_default_timezone_set("Asia/Jakarta");

		//ambil data2 dari post
		$category = $_POST['category']; $newcategory = $_POST['newcategory']; $category_desc = $_POST['deskripsi_kategori'];
		$name = $_POST['article_name']; $description = $_POST['deskripsi_artikel']; $article_id = $_POST['article_id'];
		$tag = $_POST['article_tag'];

		//kalo category baru, masukin ke tabel category dulu, trus IDnya masukin ke $category
		if ($newcategory != '') {
			$rank =  $this->article_model->get_last_category_rank() + 1;
			$category_data = array(
				'category_name' 	=> "$newcategory",
				'category_rank'		=> "$rank",
				'category_content'	=> "$category_content",
				'category_status'	=> '1'
			);
			$category =  $this->article_model->insert_new_entry_category($category_data);
		}

		//siapkan repetisi untuk tag yang bisa lebih dari satu, simpan IDnya di tagid_array
		$tagid_array = array();
		foreach ($tag as $row) {
			if ($this->article_model->is_tag_exists($row)) {
				//kalo tagnya udah ada, ambil IDnya aja
				$temp = $this->article_model->get_tag_by_name($row);
				array_push($tagid_array, $temp['0']->tag_id);
			}
			else{
				//kalo tagnya belom ada, insert si tag trus push IDnya
				array_push($tagid_array, $this->article_model->insert_tag($row));
			}
		}

		//buat array untuk input data ke tabel article dan input sekalian
		$article_data = array(
			'article_id'			=> "$article_id",
			'article_name'			=> "$name",
			'article_content'		=> "$description",
			'article_update'		=> date("Y-m-d H:i:s"),
			'category_id'			=> "$category",
			'article_status'		=> '1'
		);
		//update ke table artikel
		$this->article_model->update_entry_article($article_data);

		//mapping tag dengan artikel
		//pertama, hapus dulu tag2 yang sudah dipegang sebelumnya oleh artikel tersebut
		$this->article_model->delete_entry_tag($article_id);
		//lalu masukkan yang baru2
		foreach ($tagid_array as $row) {
			$this->article_model->insert_new_mapping($article_id,$row);
		}
		redirect(base_url()."index.php/cms");	
	}

	public function update_category()
	{
		//load model
		$this->load->model('content_model');

		//ambil data2 dari post
		$name = $_POST['name']; $content = $_POST['deskripsikategori']; $category_id = $_POST['category_id'];

		//SEQUENCE UPDATE content
		//buat array untuk input data ke tabel API dan input sekalian
		$content_data = array(
			'category_id'		=> "$category_id",
			'category_name'		=> "$name",
			'category_content'	=> "$content",
		);
		$this->content_model->update_entry_content($content_data);

		//kembali ke halaman awal
		redirect(base_url()."index.php/cms");
	}

	public function recommended_article(){
		//ambil model dan variabel dari post
		$rec = array(); $cat_id = $_POST['category_id'];
		$this->load->model('article_model');
		$this->load->model('navigation_bar_model');

		//cek apakah ada yang direkomendasikan
		//LAST SPOT
		if (array_key_exists('recommended', $_POST)) {
			foreach ($_POST['recommended'] as $value) {
				$temp = explode('b', $value);
				array_push($rec, $temp[1]);
			}
			//buang semua rekomendasi yang lama
			$this->article_model->reset_last_recommendation($cat_id);
			
			//masukkan update rekomendasi yang baru
			foreach ($rec as $value) {
				$this->article_model->set_as_recommended($value);
			}

			//kembali ke halaman awal
			redirect(base_url()."index.php/cms");
		}
	}
}