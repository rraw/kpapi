<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CMS_create extends CI_Controller
{
	//view masing2
	function add_new_article()
	{
		//load library, model, helper
		$this->load->library('ckeditor');
		$this->load->model('article_model');
		$this->load->model('navigation_bar_model');

		//atur konfigurasi dari ckeditor yang dimiliki
		$this->ckeditor->basePath = base_url().'asset/javascript/ckeditor/';
		$this->ckeditor->config['toolbar'] = array(
                array( 'Source', '-', 'Bold', 'Italic', 'Underline', 'Format','-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList', 'Image')
                                                    );
		$this->ckeditor->config['extraAllowedContent'] = 'iframe[*]';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor->config['width'] = '730px';
		$this->ckeditor->config['height'] = '300px';   

		//ambil data category dan tampilkan view
		$data['query'] = $this->article_model->get_all_category();
		$data['query_navigation'] = $this->navigation_bar_model->get_category();
		
		// Menampilkan semua view2
		$this->load->view('cms/cms_header_view');
		$this->load->view('cms/cms_navigation_bar_view',$data); 
		$this->load->view('cms/cms_add_new_article_view',$data);
		$this->load->view('cms/cms_footer_view');
	}
	
	function add_new_category()
	{
		//proses tampilan CMS dll
		//load library, model, helper
		$this->load->library('ckeditor');
		$this->load->model('article_model');
		$this->load->model('navigation_bar_model');

		//atur konfigurasi dari ckeditor yang dimiliki
		$this->ckeditor->basePath = base_url().'asset/javascript/ckeditor/';
		$this->ckeditor->config['toolbar'] = array(
                array( 'Source', '-', 'Bold', 'Italic', 'Underline', 'Format','-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','Image' )
                                                    );
		$this->ckeditor->config['extraAllowedContent'] = 'iframe[*]';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor->config['width'] = '730px';
		$this->ckeditor->config['height'] = '300px';   

		//ambil data category dan tampilkan view
		$data['query'] = $this->article_model->get_all_category();
		$data['query_navigation'] = $this->navigation_bar_model->get_category();

		//tampilkan view
		$this->load->view('cms/cms_header_view');
		$this->load->view('cms/cms_navigation_bar_view',$data);
		$this->load->view('cms/cms_add_new_category_view',$data);
		$this->load->view('cms/cms_footer_view');
	}

	//proses database
	function insert_new_article()
	{
		//load model dan set timezone
		$this->load->model('article_model'); date_default_timezone_set("Asia/Jakarta");
		
		//ambil data-data dari post
		$category = $_POST['category']; $newcategory = $_POST['newcategory']; $category_content = $_POST['deskripsikategori'];
		$name = $_POST['name']; $description = $_POST['deskripsi']; $tag = $_POST['article_tag'];
		
		//kalo category baru, masukin ke tabel category dulu, trus IDnya masukin ke $category
		if ($newcategory != '') {
			$rank =  $this->article_model->get_last_category_rank() + 1;
			$category_data = array(
				'category_name' 	=> "$newcategory",
				'category_rank'		=> "$rank",
				'category_content'	=> "$category_content",
				'category_status'	=> '1'
			);
			$category =  $this->article_model->insert_new_entry_category($category_data);
		}

		//siapkan repetisi untuk tag yang bisa lebih dari satu, simpan IDnya di tagid_array
		$tagid_array = array();
		foreach ($tag as $row) {
			if ($this->article_model->is_tag_exists($row)) {
				//kalo tagnya udah ada, ambil IDnya aja
				$temp = $this->article_model->get_tag_by_name($row);
				array_push($tagid_array, $temp['0']->tag_id);
			}
			else{
				//kalo tagnya belom ada, insert si tag trus push IDnya
				array_push($tagid_array, $this->article_model->insert_tag($row));
			}
		}

		//buat array untuk input data ke tabel article dan input sekalian
		$article_data = array(
			'article_name'			=> "$name",
			'article_content'		=> "$description",
			'article_date'			=> date("Y-m-d H:i:s"),
			'article_update'		=> date("Y-m-d H:i:s"),
			'category_id'			=> "$category",
			'article_status'		=> '1'
		);
		$article_id = $this->article_model->insert_new_entry_article($article_data);

		//mapping tag dengan artikel
		foreach ($tagid_array as $row) {
			$this->article_model->insert_new_mapping($article_id,$row);
		}

		//redirect ke halaman sesuai yang udah dibuat
		redirect(base_url()."index.php/cms/index/$article_id");
	}

	function insert_new_category()
	{
		//proses insert content ke database
		//load model dan set timezone
		$this->load->model('article_model');
		
		//ambil data-data dari post dan tabel yang sudah ada
		$name = $_POST['name']; $description = $_POST['deskripsikategori'];
		$rank =  $this->article_model->get_last_category_rank() + 1;

		//buat array untuk input data ke tabel kategori
		$content_data = array(
			'category_name'				=> "$name",
			'category_rank'				=> "$rank",
			'category_content'			=> "$description",
			'category_status'			=> '1'
		);
		$category_id = $this->article_model->insert_new_entry_content($content_data);

		//redirect kepada halaman yang baru dibuat (harusnya, tapi belom)
		redirect(base_url()."index.php/cms");
	}
}