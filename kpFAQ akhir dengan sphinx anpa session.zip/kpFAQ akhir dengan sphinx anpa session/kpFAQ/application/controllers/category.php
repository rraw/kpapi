<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Category controller
*/
class Category extends CI_Controller
{
	
	function index($category_id = NULL ,$category_name = NULL)
	{
		$this->display_header();
		$this->display_content($category_id,$category_name);
		$this->display_footer();
	}


	function display_header()
	{
		$this->load->view('header');
	}

	function display_content($category_id = NULL,$category_name = NULL)
	{
		$this->load->model('faq_model');
		// mendapatkan konten category berdasarkan id category
		$data['category_content'] = $this->faq_model->get_category_content_by_id($category_id);
		// mendapatkan artikel-artikel yang berkaitan dengan kategori
		$data['article_from_category'] = $this->faq_model->get_article_by_categoryid($category_id);
		// $data['category_name'] = $this->faq_model->get_category_name_by_id($category_id);
		$data['category_name'] = $category_name;
		$this->load->view('category_view',$data);
	} 

	function display_footer()
	{
		$this->load->view('footer');
	}

	
}

?>