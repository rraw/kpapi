<div class="container article">

<?php
foreach ($article as $row) {
	# code...
	echo "<h2>";
	echo $row->article_name;
	echo "</h2>";
	echo "<p>";
	echo $row->article_content;
	echo "</p>";

}

?>
</br>
<span>Tags</span>
<?php  

		foreach ($tags as $row) 
		{
			echo "<span class=\"tag-list\" id=\"";echo $row->tag_id;echo "\">";
			echo $row->tag_name;
			echo "</span>";
			echo "<div style=\"display: none;\" id=\"";echo $row->tag_name;echo "\"></div>";
		}
	
?>	


</div>