<div id="article-content">
	<div class="main">

	<!-- baru -->
	<form action="http://localhost/kpFAQ/index.php/cms_create/insert_new_category" method="POST">

		<!-- ##### Article NAME & CATEGORY ##### -->
		<h2>New Category</h2>
		<h3>Name</h3>
		<table id="edit-category-table">
		<tr>
			<td class="invincible">Category Name</td> 
			<td class="invincible">:
				<input class="form-control" id="article-name-form" type="text" name="name" required/></td>
		</tr>
		</table>
		</br>
 		
 		<!-- #### DESCRIPTION #### -->

		<h3>Description</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsikategori");
		?>
		
		<br>
		<button type="submit" class="submit" >Save</button>
	</form>
	
		<link rel="stylesheet" type="text/css" href="http://localhost/kpFAQ/asset/css/form.css" />

	</div>
</div>
</body>
</html>