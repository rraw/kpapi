<!-- JAVASCRIPT--> 
	<script type="text/javascript" src="http://localhost/kpFAQ/asset/javascript/expandcollapse.js"></script>
</body>
</html>		