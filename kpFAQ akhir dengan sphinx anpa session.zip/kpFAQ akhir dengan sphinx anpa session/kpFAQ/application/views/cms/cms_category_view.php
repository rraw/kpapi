<div class="main">

	<h2>
	<?php 
		foreach ($content as $row) {
			echo $row->category_name;
		
	?>
	</h2>

	<!-- Edit Button -->
	<button type="submit" value="Edit" id="editcategory">Edit</button>
	
	<!-- Delete Button -->
	<button value="delete" type="button" id="deletecategory">Delete</button>

	<!-- Status Button -->
	<button value="active" type="button" id="category-status">Activated</button>

	<!-- script for update category status active/inactive -->

	<script type="text/javascript">

		var id = <?php echo $row->category_id; ?>;
		var active = "1";
		var inactive = "0";
		var status = <?php echo $row->category_status; ?>;

		if (status == 1) 
		{
			$("#category-status").val("active");
			$("#category-status").html("Activated");
			$("#category-status").addClass("status-active");
		} else {
			$("#category-status").val("inactive");
			$("#category-status").html("Inactivated");
		};

		$("#category-status").click(function(){

			if ($(this).val() == "active"){
				
				$(this).html("Inactivated");
				$(this).val("inactive");
				$(this).removeClass("status-active");
				$.post("http://localhost/kpFAQ/index.php/cms/update_category_status/",
		        {   
		            category_id: id,
		            status: inactive
	    		},

		        function(data,status)
		        {   
		            alert(data);        
		        });
				

			} else {
				
				$("#category-status").addClass("status-active");
				$("#category-status").html("Activated");
				$(this).val("active");
				$.post("http://localhost/kpFAQ/index.php/cms/update_category_status/",
		        {
		            
		            category_id: id,
		            status: active
	    		},

		        function(data,status)
		        {   
		            alert(data);        
		        });
		
			}//endif
		});

	</script>

	<p>
	<?php 
		
		echo $row->category_content;
			
		}
	?>
	</p>

	<div id="article_rows">
		<form method="POST" action="http://localhost/kpFAQ/index.php/cms_update/recommended_article">
			<table>
				<tr>
					<th>*</th>
					<th>Status</th>
					<th>Title</th>
					<th>Tags</th>
					<th>Actions</th>
				</tr>
				<?php
					//inisiasi untuk akses tags
					$i = 0; 
					foreach ($article as $value): 
				?>
					<?php  
						echo '<tr class="table_row">';
							if ($value->article_status==127) {
								echo '<td><input type="checkbox" class="recommended" name="recommended[]" value="cb'.$value->article_id.'" checked></td>';
							}
							else{
								echo '<td><input type="checkbox" class="recommended" name="recommended[]" value="cb'.$value->article_id.'"></td>';
							}
							if ($value->article_status) {
								//active
								echo '<td><button value="active" type="button" class="article-status status-active" id="act'.$value->article_id.'">Activated</button></td>';
							}
							else{
								//inactive
								echo '<td><button value="inactive" type="button" class="article-status" id="act'.$value->article_id.'">Inactivated</button></td>';
							}
							echo '<td class="article_name">'.$value->article_name.'</td>';
							echo '<td>'; 
							foreach ($tag_array[$i] as $tag) {
								if (!empty($tag['tag_name'])) {
									print $tag['tag_name']; echo ', ';	
								}
							};
							echo '</td>';
							echo '<td>'; 
								echo '<button value="edit" type="button" class="editarticle" id="edit'.$value->article_id.'">Edit</button>';
								echo '<button value="delete" type="button" class="deletearticle" id="del'.$value->article_id.'">Delete</button>';
							echo '</td>';
						echo '</tr>';
					?>
				<?php
					$i++; 
					endforeach
				?>
				<tr>
					<input type="hidden" name="category_id" value="<?php echo $content[0]->category_id ?>">
				</tr>
			</table>
			Harus dipilih 5 rekomendasi <br>
			<button type="submit" class="submit" id="submit-rec">Save</button>
		</form>

		<!-- SCRIPT BUAT ARTICLE ACTIVATION -->
		<script type="text/javascript" src="http://localhost/kpFAQ/asset/javascript/tag-it.js"></script>
	<script type="text/javascript" src="http://localhost/kpFAQ/asset/javascript/local.js"></script>
		<script type="text/javascript" src="http://localhost/kpFAQ/asset/javascript/delete.js"></script>
		<script type="text/javascript" src="http://localhost/kpFAQ/asset/javascript/ckeditor/ckeditor.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			//limit checkbox
			$(".recommended").on('change', function(evt) {
   				if($(".recommended:checkbox:checked").length > 5) {
       				this.checked = false;
       				alert('Maximum amount of recommended article');
   				}
   				else if($(".recommended:checkbox:checked").length < 5){
   					$("#submit-rec").prop("disabled",true);
   				}
   				else{
   					$("#submit-rec").prop("disabled",false);
   				}
			});

			$(".article-status").click(function(){
				var id = '#'+$(this).prop("id");

				//action dari button status
				if ($(id).val()=="active"){
					$(id).removeClass("status-active");
					$(id).html("Inactivated");
					$(id).val("inactive");
					$.post("http://localhost/kpFAQ/index.php/cms/update_article_status/",
			        {
			            article_id: id,
			            status: '0'
		    		},

			        function(data,status)
			        {   
			            alert(data);        
			        });
				} else {
					$(id).addClass("status-active");
					$(id).html("Activated");
					$(id).val("active");
					$.post("http://localhost/kpFAQ/index.php/cms/update_article_status/",
			        {
			            article_id: id,
			            status: '1'
		    		},

			        function(data,status)
			        {   
			            alert(data);        
			        });
				}//endif
			});
		});
		</script>
	</div>

	
	<div id="category-editor">

	<!-- baru -->
	<form action="http://localhost/kpFAQ/index.php/cms_update/update_category" method="POST">

		<!-- ##### Article NAME & CATEGORY ##### -->
		<h2>Editor</h2>
		<h3>Name</h3>
		<table id="edit-category-table">
		<tr>
			<td class="invincible">Category Name</td> 
			<td class="invincible">:
				<input class="form-control" id="article-name-form" type="text" name="name" value="<?php echo $content[0]->category_name ?>" required/></td>
		</tr>
		</table>
		</br>
 		
 		<!-- #### DESCRIPTION #### -->

		<h3>Description</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsikategori",$content[0]->category_content);
			echo '<input type="hidden" id="category_id" name="category_id" value="'.$row->category_id.'">';
			echo '<input type="hidden" id="category_name" value="'.$row->category_name.'">';
		?>
		
		<br>
		<button type="submit" class="submit" >Save</button>
	</form>

	</div>
	
</div>