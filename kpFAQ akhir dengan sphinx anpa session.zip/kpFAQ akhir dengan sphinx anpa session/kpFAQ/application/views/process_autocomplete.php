<?php
mysql_connect("localhost","root","");
mysql_select_db("faqtiket");

$word_search = strtolower($_GET["word_search"]);
if (!$word_search) return;

$sql = mysql_query("select article_name from article where article_name LIKE '%$word_search%'");
while($r = mysql_fetch_array($sql)) {
	$nama_barang = $r['article_name'];
	echo "$nama_barang \n";
}
?>
