
<?php
    //untuk Sphinx Search 
    $CONF = array();
    $CONF['sphinx_host'] = 'localhost';
    $CONF['sphinx_port'] = 9312; //this demo uses the SphinxAPI interface
    $CONF['mysql_host'] = "localhost";
    $CONF['mysql_username'] = "root";
    $CONF['mysql_password'] = "";
    $CONF['mysql_database'] = "faqtiket";
    $CONF['sphinx_index'] = "rt"; // can also be a list of indexes, "main, delta"
    $CONF['body'] = 'excerpt';  // can use 'excerpt' to highlight using the query, or 'asis' to show description as is.
    // $CONF['link_format'] = '/page.php?page_id=$id';  // the link for the title (only $id) placeholder supported
    $CONF['link_format'] = 'http://localhost/kpFAQ/index.php/article/index/$id/$id' ;  // the link for the title (only $id) placeholder supported
    $CONF['debug'] = TRUE;
    $CONF['page_size'] = 10; # How many results per page
    $CONF['max_matches'] = 1000;  # maximum number of results - should match sphinxes max_matches. default 1000
    // $CONF['mysql_query'] = '
    //                         SELECT article_id AS id, article_name AS title, article_content AS body
    //                         FROM article
    //                         WHERE article_id IN ($ids)
    //                         ';
    $CONF['mysql_query'] = '
                            SELECT article.article_id AS id, article.article_name AS title, article.article_content AS body, 
                            category.category_name AS category_title, tag.tag_name AS tag_title
                            FROM article, category, mapping, tag
                            WHERE (article.category_id=category.category_id) AND (article.article_id=mapping.article_id) 
                            AND (mapping.tag_id=tag.tag_id) AND (article.article_id IN ($ids))
                            UNION ALL
                            SELECT article.article_id AS id, article.article_name AS title, article.article_content AS body, 
                            category.category_name AS category_title, "" AS tag_title
                            FROM article, category
                            WHERE (article.category_id=category.category_id) AND (article.article_id IN ($ids))
                            ';

    //Sanitise the input
    //q = word_search / pencarian di search box
    $q = isset($_GET['q'])?$_GET['q']:'';
    $q = preg_replace('/ OR /',' | ',$q);
    $q = preg_replace('/[^\w~\|\(\)\^\$\?"\/=-]+/',' ',trim(strtolower($q)));

//Display the HTML search form

?>

<div class="container article">
 
    <?php

        //If the user entered something
        if (!empty($q)) 
        {
            //produce a version for display
            $qo = $q;
            if (strlen($qo) > 64) 
            {
                $qo = '--complex query--';
            }
            
            if (1) 
            {
                //RUMUS PENCARIAN
                //Choose an appriate mode (depending on the query)
                $mode = SPH_MATCH_ALL;
                if (substr_count($q,' ') > 2) //over 2 words
                {
                    $conjunction =
                        array(
                            "and", "dan",
                            "but", "tapi", "tetapi",
                            "or", "atau",
                            "nor", "maupun",
                            "for", "untuk", "bagi", "demi", "selama", "buat", 
                            "yet", "sudah", "namun",
                            "so", "jadi", "sekali", "demikian", "juga",
                            "it", "nya", "ia",
                            "the", "sang",
                            "at", "pada", "kepada", "waktu", "atas",
                            "with", "dengan",
                            "on", "di atas", "di", "tentang", "dalam", "mengenai", "demi",
                            "under", "di bawah", "menurut",
                            "in", "di dalam", "secara", "menurut",
                            "between", "antara", "di antara",
                            "as", "sebagai", "ketika", "betapa",
                            "before", "sebelum", "dahulu",
                            "after", "setelah", "sesudah", "lewat", "kemudian",
                            "because", "karena", "sebab", "lantaran",
                            "to", "hingga", "kurang", "terhadap", "ke",
                            "from", "dari", "mulai",
                            "than", "daripada",
                            "since", "sejak", "semenjak",
                            "this", "ini",
                            "that", "itu", "yang", "bahwa", "sehingga", "kalau", "supaya",
                            "then", "maka", "pun",
                            "thus", "begini", "begitu",
                            "until", "sampai", "ketika", "padahal", "jika", "bila",
                            "such", "sungguh",
                            "some", "beberapa",
                            "many", "banyak",
                            "much", "jauh",
                            "little", "few", "sedikit",
                            "i", "saya", "aku",
                            "you", "kamu", "kalian",
                            "we", "kita", "kami", 
                            "they", "mereka",
                            "he", "she", "dia",
                            "our", "punya",
                            "will", "akan",
                            "your", "her", "his", "my", "their",
                            "is", "am", "are", "was", "were", "adalah", "ialah", "merupakan",
                            );
                    foreach ($conjunction as $row)
                    {
                        $q = str_replace($conjunction,'',$q); //menghilangkan kata-kata penghubung, sifat, imbuhan                       
                    }
                    $mode = SPH_MATCH_ANY;
                }
                // if (strpos($word_search,'~') === 0) 
                // {
                //     $word_search = preg_replace('/^\~/','',$word_search);
                //     if (substr_count($word_search,' ') > 2) //over 2 words
                //         $mode = SPH_MATCH_ANY;
                // } 
                // elseif (preg_match('/[\|\(\)\^\$\?"\/=-]/',$word_search)) 
                // {
                //     $mode = SPH_MATCH_EXTENDED;
                // }
                
                //setup paging...
                if (!empty($_GET['page'])) 
                {
                    $currentPage = intval($_GET['page']);
                    if (empty($currentPage) || $currentPage < 1) {$currentPage = 1;}
                    
                    $currentOffset = ($currentPage -1)* $CONF['page_size'];
                    
                    if ($currentOffset > ($CONF['max_matches']-$CONF['page_size']) ) 
                    {
                        die("Only the first {$CONF['max_matches']} results accessible");
                    }
                } 
                else 
                {
                    $currentPage = 1;
                    $currentOffset = 0;
                }
                
                //Connect to sphinx, and run the query
                $cl = new SphinxClient();
                $cl->SetServer($CONF['sphinx_host'], $CONF['sphinx_port']);
                $cl->SetSortMode(SPH_SORT_EXTENDED, "@relevance DESC, @id DESC");
                $cl->SetMatchMode($mode);
                $cl->SetLimits($currentOffset,$CONF['page_size']); //current page and number of results
                
                $res = $cl->Query($q, $CONF['sphinx_index']);
                $res = $cl->Query($q);
                
                // echo "<pre>";
                // print_r($res);die;
                //Check for failure
                if (empty($res)) 
                {
                    print "Query failed: -- please try again later.\n";
                    if ($CONF['debug'] && $cl->GetLastError())
                        print "<br/>Error: ".$cl->GetLastError()."\n\n";
                    return;
                } 
                else 
                {
                    //We have results to display!
                    // if ($CONF['debug'] && $cl->GetLastWarning())
                    //     print "<br/>WARNING: ".$cl->GetLastWarning()."\n\n";if (array_key_exists('matches', $res))
                                       
                    //validasi matches
                    if (array_key_exists('matches', $res))
                    {
                        $query_info = "Query '".htmlentities($qo)."' retrieved ".count($res['matches'])." of $res[total_found] matches in $res[time] sec.\n";
                    } 
                    else 
                    {
                        //do nothing
                    }

                    $resultCount = $res['total_found'];
                    $numberOfPages = ceil($res['total']/$CONF['page_size']);
                }
                
                // if (is_array($res["matches"])) {
                //     //Build a list of IDs for use in the mysql Query and looping though the results
                //     $ids = array_keys($res["matches"]);
                // } else {
                //     print "<pre class=\"results\">No Results for '".htmlentities($qo)."'</pre>";
                // }

                if (array_key_exists('matches', $res))
                {
                    if (is_array($res["matches"])) 
                    {
                        //Build a list of IDs for use in the mysql Query and looping though the results
                        $ids = array_keys($res["matches"]);
                    } 
                    else 
                    {
                        print "<pre class=\"results\">No Results for '".htmlentities($qo)."'</pre>";
                    }

                } 
                else 
                {
                    echo "no result matches in $res[time] sec.\n";
                }
            }
            
            //We have results to display
            if (!empty($ids)) 
            {
                //Setup Database Connection
                // $db = mysql_connect($CONF['mysql_host'],$CONF['mysql_username'],$CONF['mysql_password']) or die("ERROR: unable to connect to database");
                // mysql_select_db($CONF['mysql_database'], $db) or die("ERROR: unable to select database");
                
                //Run the Mysql Query
                $sql = str_replace('$ids',implode(',',$ids),$CONF['mysql_query']);
                $result = mysql_query($sql) or die($CONF['debug']?("ERROR: mysql query failed: ".mysql_error()):"ERROR: Please try later");
                
                if (mysql_num_rows($result) > 0) 
                {
                    //Fetch Results from Mysql (Store in an accociative array, because they wont be in the right order)
                    $rows = array();
                    while ($row = mysql_fetch_array($result,MYSQL_ASSOC)) 
                    {
                        $rows[$row['id']] = $row;
                    }

                    //Call Sphinxes BuildExcerpts function
                    if ($CONF['body'] == 'excerpt') 
                    {
                        $docs = array();
                        foreach ($ids as $c => $id) 
                        {
                            $docs[$c] = strip_tags($rows[$id]['body']);
                        }
                        $reply = $cl->BuildExcerpts($docs, $CONF['sphinx_index'], $q);
                    }
                    
                    if ($numberOfPages > 1 && $currentPage > 1) 
                    {
                        print "<p class='pages'>".pagesString($currentPage,$numberOfPages)."</p>";
                    }
                    
                    //Actully display the Results
                    // print "<ol class=\"results\" start=\"".($currentOffset+1)."\">";
                    print "<ol class=\"results\" start=\"".($currentOffset+1)."\">";
                    foreach ($ids as $c => $id) 
                    {
                        $row = $rows[$id];

                        // $link = htmlentities(str_replace('$id',$row['id'],$CONF['link_format'));
                        $linktitle = preg_replace('/\W+/s','-',$row['title']); //Fungsi untuk mengganti semua special charakter dan spasi dengan '-'
                        $link = htmlentities(str_replace('$id',$row['id'],'http://localhost/kpFAQ/index.php/article/index/$id/'.$linktitle));
                        print "<li><a href=\"$link\">".htmlentities($row['title'])."</a><br/>";
                                               
                        if ($CONF['body'] == 'excerpt' && !empty($reply[$c]))
                            print ($reply[$c])."</li>";
                        else
                            print htmlentities($row['body'])."</li>";
                    }
                    print "</ol>";
                    
                    if ($numberOfPages > 1) 
                    {
                        print "<p class='pages'>Page $currentPage of $numberOfPages. ";
                        printf("Result %d..%d of %d. ",($currentOffset)+1,min(($currentOffset)+$CONF['page_size'],$resultCount),$resultCount);
                        print pagesString($currentPage,$numberOfPages)."</p>";
                    }
                    
                    print "<pre class=\"results\">$query_info</pre>";

                } 
                else 
                {
                    //Error Message
                    print "<pre class=\"results\">Unable to get results for '".htmlentities($qo)."'</pre>";
                }
            }
        }


        #########################################
        # Functions 
        # Created by Barry Hunter for use in the geograph.org.uk project, reused here because convenient :)

        function linktoself($params,$selflink= '') 
        {
            $a = array();
            $b = explode('?',$_SERVER['REQUEST_URI']);
            if (isset($b[1])) 
                parse_str($b[1],$a);

            if (isset($params['value']) && isset($a[$params['name']])) 
            {
                if ($params['value'] == 'null') 
                {
                    unset($a[$params['name']]);
                } 
                else 
                {
                    $a[$params['name']] = $params['value'];
                }

            } 
            else 
            {
                foreach ($params as $key => $value)
                    $a[$key] = $value;
            }

            if (!empty($params['delete'])) 
            {
                if (is_array($params['delete'])) 
                {
                    foreach ($params['delete'] as $del) 
                    {
                        unset($a[$del]);
                    }
                } 
                else 
                {
                    unset($a[$params['delete']]);
                }
                unset($a['delete']);
            } 
            if (empty($selflink)) 
            {
                $selflink = $_SERVER['SCRIPT_NAME'];
            } 
            if ($selflink == '/index.php') 
            {
                $selflink = '/';
            }

            return htmlentities($selflink.(count($a)?("?".http_build_query($a,'','&')):''));
        }


        function pagesString($currentPage,$numberOfPages,$postfix = '',$extrahtml ='') 
        {
            static $r;
            if (!empty($r))
                return($r);

            if ($currentPage > 1) 
                $r .= "<a href=\"".linktoself(array('page'=>$currentPage-1))."$postfix\"$extrahtml>&lt; &lt; prev</a> ";
            $start = max(1,$currentPage-5);
            $endr = min($numberOfPages+1,$currentPage+8);

            if ($start > 1)
                $r .= "<a href=\"".linktoself(array('page'=>1))."$postfix\"$extrahtml>1</a> ... ";

            for($index = $start;$index<$endr;$index++) 
            {
                if ($index == $currentPage) 
                    $r .= "<b>$index</b> "; 
                else
                    $r .= "<a href=\"".linktoself(array('page'=>$index))."$postfix\"$extrahtml>$index</a> ";
            }
            if ($endr < $numberOfPages+1) 
                $r .= "... ";

            if ($numberOfPages > $currentPage) 
                $r .= "<a href=\"".linktoself(array('page'=>$currentPage+1))."$postfix\"$extrahtml>next &gt;&gt;</a> ";

            return $r;
        }
    ?>

</div>