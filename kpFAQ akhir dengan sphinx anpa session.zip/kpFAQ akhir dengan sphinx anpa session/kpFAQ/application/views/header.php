<!DOCTYPE html>

<html>
<head>
	<!-- Javascript -->
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="http://localhost/kpFAQ/asset/javascript/display.js"></script>


	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="http://localhost/kpFAQ/asset/css/style.css">

	<!-- font awesome -->
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

	<title>tiket.com FAQ</title>
</head>

<header>
<h1>tiket.com frequent ask question</h1>
<a href="http://localhost/kpFAQ">Home</a>
</header>

<body>

