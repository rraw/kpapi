</body>

<footer>
This is footer
</footer>

