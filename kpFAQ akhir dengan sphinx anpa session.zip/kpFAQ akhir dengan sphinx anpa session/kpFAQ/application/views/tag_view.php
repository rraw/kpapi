<div class="container tag-view">




<h1> Tag
<?php 
$string = explode("-", $tag_name);
		foreach ($string as $key) {
			# code...
			echo $key;
			echo " ";
		}
?>
</h1>

<?php

		echo "<h4>";
		echo "Artikel Terkait";
		echo "</h4>";
		// Printing every article in selected tag
		foreach ($article_list as $row) 
		{
			# code...
?>
		<div class ="article-title article-tag" id="<?php echo $row->article_id; ?>">
			<h4><?php  echo $row->article_name;?></h4>
		</div>
<?php  
		echo "<div id=\"".$row->article_name."\" style=\"hidden\"></div>";

?>


<?php
		}

?>


</div>