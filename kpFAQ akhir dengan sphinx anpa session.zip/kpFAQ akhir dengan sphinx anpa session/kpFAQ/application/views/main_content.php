<div class="main-content">
This is main content
</div>
