<!-- <div class="main-content"> -->

<div class="container"> 
	<div class="search-box">
		<form id="form_search" name="form_search" method="get" action="">
            <input name="q" type="text" id="q" value="" placeholder="Enter Question" class="demo"</input> 
        </form>
        		<!-- Displaying tag -->
	<div class="tag-box">

<?php  
		foreach ($tag_list as $row) 
		{
			echo "<span class=\"tag-list\" id=\"";echo $row->tag_id;echo "\">";
			echo $row->tag_name;
			echo "</span>";
			echo "<div style=\"display: none;\" id=\"";echo $row->tag_name;echo "\"></div>";
		}
?>	
	</div>
	<!-- end of search box -->
	</div>
<?php 
	if (!empty($_GET['q']))
	{
		require("sphinxapi.php");            # perintah sphinx
		$this->load->view('search_data');    # perintah sphinx
	}
	else
	{
		static $count = 0;
		foreach ($category as $row) {

			// Creating div for each category
			if ($count==0) 
			{
				echo "<div class=\"left content\" >";
				$count=1;
			} else 
			{
				echo "<div class=\"right content\" >";
				$count=0;
			}
				echo "<h2 class=\"category-tag\" id=\"".$row->category_id."\">";
				echo $row->category_name;
				echo "</h2>";
				echo "<div id=\"".$row->category_name."\" style=\"hidden\"></div>";
				// Displaying Latest Article
				echo "<h3>Latest Article</h3>";
				foreach ($latest_article[$row->category_id] as $rows) 
				{
					echo "<div class=\"tag article-tag\" id=\"".$rows->article_id. "\">";
					echo $rows->article_name;
					echo "</div>";
					echo "<div id=\"".$rows->article_name."\" style=\"hidden\"></div>";
				}
				// Displaying Most seen Article in 3 month
				echo "<h3>Most seen article in 3 month</h3>";
				foreach ($most_seen_article[$row->category_id] as $rows) 
				{
					echo "<div class=\"tag article-tag\" id=\"".$rows->article_id. "\">";
					echo $rows->article_name;
					echo "</div>";
					echo "<div id=\"".$rows->article_name."\" style=\"hidden\"></div>";
				}
				// displaying recomended article
				echo "<h3>Recomended Article</h3>";
				foreach ($recomended_article[$row->category_id] as $rows) 
				{
					echo "<div class=\"tag article-tag\" id=\"".$rows->article_id. "\">";
					echo $rows->article_name;
					echo "</div>";
					echo "<div id=\"".$rows->article_name."\" style=\"hidden\"></div>";
				}
				// End of content
				echo "</div>";
			}
	}
?> 
<!-- end of container -->
</div>

<!-- end of main content -->
<!-- </div> -->
