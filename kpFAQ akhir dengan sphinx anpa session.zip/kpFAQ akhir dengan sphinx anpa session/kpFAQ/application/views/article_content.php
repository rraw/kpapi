<div class="container">
This article content
</div>