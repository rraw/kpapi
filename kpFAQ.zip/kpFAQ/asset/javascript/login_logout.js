$(document).ready(function() 
{
	var base_url = "http://localhost/kpFAQ/"
	$(".log-out").click(function()
	{
		if (confirm("Are you sure?")) 
		{
			$.post("http://localhost/kpFAQ/index.php/login/log_out/",
				{
					
				},
				function(data){
					alert("Log out succeed");
					window.location.replace("http://localhost/kpFAQ/index.php/login");
				});

		};
	});

	$("#home").click(function(){
		var url = base_url+"index.php/login";
		window.location.replace(url);
		// body...
	});

});