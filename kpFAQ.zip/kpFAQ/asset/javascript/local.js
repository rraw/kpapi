$(document).ready(function(){

    var base_url = "http://localhost/kpFAQ/";

    $(".editarticle").click(function(){
        id = $(this).prop("id");
        $("#article-content").load(base_url+"index.php/cms/display_article_content/"+id);
    });

    $("#editcategory").click(function(){
        $("#article_rows").hide();
        $("#category-editor").show();
        $('html,body').animate({
            scrollTop:$("#category-editor").offset().top-50},
            600);
    });

    $("#article_tags").tagit({
        // Options
        fieldName: "article_tag[]",
        availableTags: ["c++", "java", "php", "javascript", "ruby", "python", "c"],
        autocomplete: {delay: 0, minLength: 2},
        showAutocompleteOnFocus: false,
        removeConfirmation: false,
        caseSensitive: true,
        allowDuplicates: false,
        allowSpaces: true,
        readOnly: false,
        tagLimit: null,
        singleField: false,
        singleFieldDelimiter: ',',
        singleFieldNode: null,
        tabIndex: null,
        placeholderText: null,

        // Events
        beforeTagAdded: function(event, ui) {
            console.log(ui.tag);
        },
        afterTagAdded: function(event, ui) {
            console.log(ui.tag);
        },
        beforeTagRemoved: function(event, ui) {
            console.log(ui.tag);
        },
        onTagExists: function(event, ui) {
            console.log(ui.tag);
        },
        onTagClicked: function(event, ui) {
            console.log(ui.tag);
        },
        onTagLimitExceeded: function(event, ui) {
            console.log(ui.tag);
        }

    });

    $("#show_tags").tagit({
        // Options
        fieldName: "show_tag[]",
        availableTags: ["c++", "java", "php", "javascript", "ruby", "python", "c"],
        autocomplete: {delay: 0, minLength: 2},
        showAutocompleteOnFocus: false,
        removeConfirmation: false,
        caseSensitive: true,
        allowDuplicates: false,
        allowSpaces: true,
        readOnly: true,
        tagLimit: null,
        singleField: false,
        singleFieldDelimiter: ',',
        singleFieldNode: null,
        tabIndex: null,
        placeholderText: null,

        // Events
        beforeTagAdded: function(event, ui) {
            console.log(ui.tag);
        },
        afterTagAdded: function(event, ui) {
            console.log(ui.tag);
        },
        beforeTagRemoved: function(event, ui) {
            console.log(ui.tag);
        },
        onTagExists: function(event, ui) {
            console.log(ui.tag);
        },
        onTagClicked: function(event, ui) {
            console.log(ui.tag);
        },
        onTagLimitExceeded: function(event, ui) {
            console.log(ui.tag);
        }

    });
    
    $('select[name=category]').change(function () 
    {
        if ($(this).val() == '-1') 
        {
            $('#newcategory').show();
            $('#category_desc').show();
        } 
        else 
        {
            $('#newcategory').hide();
            $('#category_desc').hide();
        }
    });
});