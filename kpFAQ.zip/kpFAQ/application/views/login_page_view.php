<!DOCTYPE HTML>

<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />

	<title>Login page</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/css/login_style.css">
	<!-- favicon -->
	<link href="<?php echo base_url(); ?>asset/image/favicon.ico" rel="shortcut icon" type="icon">

	<!-- script -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/login_logout.js"></script> 
    
</head>
<body>

<div class="login-container">
	<img src="<?php echo base_url(); ?>asset/image/logo_tiket.png">
	<h2>FAQ blog CMS</h2>
	<table>
		<tr>	
			<td>Username</td>
			<td>: <input type="text" id="username"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td>: <input type="password" id="password"></td>
		</tr>	
		<tr>
			<td></td>
			<td><a id="login-btn"><p>Log In</p></a></td>
		</tr>
	</table>

</div>

</body>
<footer>

<script type="text/javascript" > 
	$(document).ready(function() 
	{
		// Log in
		var authenticate = function()
		{

			var username = $("input#username").val();
			var password = $("input#password").val();


			$.post("<?php echo base_url(); ?>index.php/login/authentication/",
				// parameter yang di post
				{
					username:username,
					password:password,
				},

				// retrieve data contain user role and logged_in
				function(data)
				{
					var user_role = '';
					var user_log_in = false;

					if (!($.isEmptyObject(data))) 
					{
						$.each( data, function( key, value ) 
						{
							user_log_in = value;
					  // alert( key + ": " + value );
						});
					};

					if (user_log_in) {
						// Login sukses
						alert("Login Succeed");
						// user = admin
						window.location.replace("<?php echo base_url(); ?>index.php/cms");

					} else {
						// Login failed
						$("#username").addClass("wrong_input");
						alert("Your Usename or Password is invalid");
					};
				},"json");

		// // end of authenticate function
		}

		$("#login-btn").click(authenticate);

	});
</script>
</footer>
</html>