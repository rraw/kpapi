<div class="side">
<div class="inside">

<div class="button-group" id="add-content">
    <div class="main-btn">
        <h2> + New Content</h2>
    </div>
    <div class="sub-btn"><a>
        <form method="" class="form-hid2" action="<?php echo base_url(); ?>index.php/cms_create/add_new_category">
            <button class="menuadd" value="Add New" type="submit" id="add-content">Add Category</button>
        </form></a>
    </div>
    <div class="sub-btn"><a>
        <form method="" class="form-hid2" action="<?php echo base_url(); ?>index.php/cms_create/add_new_article">
            <button class="menuadd" value="Add New" type="submit" id="add-article">Add Article</button>
        </form></a>
    </div>
</div>

    <!-- button untuk edit rank -->
    <button id="edit_rank_button" class="button-group"><h2>Edit Category Rank</h2></button>


    <!-- ########### BAGIAN LOOP category###########-->
<?php 

// Row adalah sebuah array yang menyimpan nama category dan id category 
foreach ($query_navigation as $row) {
    static $count = 1;
    //ambil nama category
    $category_name = $row->category_name;
    //ambil id category
    $category_id = $row->category_id;
        
?>

<!-- UNTUK YANG BERTIPE article -->
    <div class="trigger b" id="<?php echo $category_id; ?>"> 
        <a href="#" id="<?php echo $category_id; ?>">
        <?php 
            if ($count<=9) {
                echo"0";
            }
            echo $count;
            echo " ";
            print $category_name;
            $count=$count+1;
        ?>
    </a>
    </div>

 <script type="text/javascript"> 
    $(document).ready(function(){
        $("#edit_rank_button").click(function(){
            $('#article-content').
            load('<?php echo base_url(); ?>index.php/cms/edit_rank/');
        });
    });
</script>

<?php 
} // END OF CATEGORYLOOPING
?>
                
<!-- end of inside -->
</div>
<!-- end of side -->
</div>