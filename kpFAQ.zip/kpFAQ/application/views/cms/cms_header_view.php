<!DOCTYPE HTML>

<html>
	<head>

		<title>tiket.com FAQ</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />

		<!-- FONT -->
		<link href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet" type="text/css">

		<!-- FAVICON --> 
		<link href="<?php echo base_url(); ?>/asset/image/favicon.ico" rel="shortcut icon" type="icon">
		
    	<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/flick/jquery-ui.css">
    	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/css/jquery.tagit.css">
    	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/css/form.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/css/style-cms.css">
		
		<!-- SCRIPT -->
		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
		<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.12/jquery-ui.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo base_url(); ?>asset/javascript/login_logout.js"type="text/javascript"></script>
	</head>

	<!--  #################### BODY ####################-->

	<body>

		<!-- HEADER -->
		<!-- ********************************************************* -->
		<div class="container">
			<header>
			<p style="margin-right:15px"><a>Welcome, <b>admin</b></a> | <a class="log-out">Log Out</a></p>
			<a href="#"><img src="<?php echo base_url(); ?>asset/image/logo_tiket.png" width="232" height="49"></a>
			<div class="clear"></div>
			</header>
			<div class="head">
			<h2>Welcome to</h2>
			<h1>FAQ CMS ? ? </h1>
		</div>




