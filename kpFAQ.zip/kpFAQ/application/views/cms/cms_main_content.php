

	<!-- DIV YANG AKAN DIGANTI GANTI KONTEN -->
	<div id="article-content">

	</div>
