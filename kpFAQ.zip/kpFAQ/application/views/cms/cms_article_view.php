<div class="main">
	<!-- DESKRIPSI -->
	<!-- ############ article DESCRIPTION SECTION ##########-->
	<div id="deskripsi">
	<?php	
			foreach ($query_konten as $rows) 
			{
				//article name
				echo "<h2>";
				print $rows->article_name;
				echo "</h2>";

				//date craete sama update
				echo '<div class="date">';
				echo "created $rows->article_date, ";
				echo "updated $rows->article_update";
				echo '</div>';

				//hidden input buat dipegang oleh updater/view2an
				echo '<input type="hidden" id="article_id" value="'.$rows->article_id.'">';
				echo '<input type="hidden" id="article_name" value="'.$rows->article_name.'">';

				//tags
				echo '<h3>Tag Terkait</h3>';
				echo '<ul id="show_tags" name="show_tags">';
					foreach ($tag_array as $row) {
						echo '<li>';
						print $row['tag_name'];
						echo '</li>';
					}
				echo '</ul>';

				//konten artikel
				echo "<h3>Konten Artikel</h3>";
				$text= $rows->article_content;
				echo "<p>$text</p>";
				echo "</br>";
			}
 	?>
	<!-- end of deskripsi -->
	</div>
	
	<!-- SCRIPT HANYA MAU DI SINI -->
	<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/tag-it.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/local.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/delete.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/ckeditor/ckeditor.js"></script>
	
	<div id="article-editor">
		<h2>Editor</h2>
		<form action="<?php echo base_url(); ?>index.php/cms_update/update_article" method="POST">

		<!-- ##### Article NAME & CATEGORY ##### -->
		<h3>Article Name &amp; Category</h3>
		<table id="edit-category-table">
			<tr>
				<td class="invincible" style="width:120px;">Category</td>
				<td class="invincible">
					<select name="category" id="choose-category">
			 			<?php 
			 				foreach ($query_konten as $rows) {
			 					foreach ($query as $value) {
			 						echo '<option value="';
			 						print $value->category_id;
			 						echo '" ';
		 							if ($rows->category_id==$value->category_id) {
		 								echo "selected=\"selected\"";
		 							}
			 						echo '">';
			 						print $value->category_name;
			 						echo '</option>';		
			 					}
			 				}
			 			?>
			 			<option value="-1">(new category)</option>
			 		</select>
			 	</td>
			 	<td class="invincible">
	    				<p id="newcategory">New Category Name :  <label id="categorylabel"><input id="new-category-form" class="form-control" name="newcategory" type="text" placeholder="New Category Name"/></label></p>
	    		</td>
			</tr>
			<tr>
				<td class="invincible">Article Name</td> 
				<td class="invincible">
					<input class="form-control" id="article-name-form" type="text" name="article_name" value="<?php echo $query_konten[0]->article_name ?>" required/></td>
			</tr>
		</table>
		</br>

			<!-- ## Deskripsi Kategori ## -->
			<div id="category_desc">
			<h3>Category Description</h3>
			<?php
				echo $this->ckeditor->editor("deskripsi_kategori");
				
			?>
			<br>
			</div>
	 		
	 		<!-- #### DESCRIPTION #### -->
			<h3>Article Content</h3>
			<?php
				foreach ($query_konten as $rows) {
					echo $this->ckeditor->editor("deskripsi_artikel",$rows->article_content);  
				  }  
			?>
			<br>

			<!-- #### TAGGING #### -->
			<h3>Article Tag</h3>
			Pisahkan tag dengan , (koma)
			<ul id="article_tags" name="article_tags">
	    		<!-- Existing list items will be pre-added to the tags -->
				<?php  
					foreach ($tag_array as $row) {
						echo '<li>';
						print $row['tag_name'];
						echo '</li>';
					}
				?>
			</ul>

			<?php  
				echo '<input type="hidden" name="article_id" id="article_id" value="'.$rows->article_id.'">';
				echo '<input type="hidden" id="article_name" value="'.$rows->article_name.'">';
			?>
			<!-- SUBMIT -->
			<button type="submit" class="submit" >Save</button>
	</form>
	<script type="text/javascript">
		$(document).ready(function(){
			//animasi ke editor
			$('html,body').animate({
            scrollTop:$("#article-editor").offset().top-50},
            600);
		});
	</script>

	</div>
<!-- end of main -->
</div>