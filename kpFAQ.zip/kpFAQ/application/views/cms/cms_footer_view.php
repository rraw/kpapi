<!-- JAVASCRIPT--> 
	<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/expandcollapse.js"></script>
</body>
</html>		