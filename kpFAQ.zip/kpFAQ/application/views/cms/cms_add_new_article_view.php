<div id="article-content">
	<div class="main">

	<!-- baru -->
	<form action="<?php echo base_url(); ?>index.php/cms_create/insert_new_article" method="POST">

	<!-- ##### Article NAME & CATEGORY ##### -->
	<h2>New Article</h2>
	<h3>Article Name &amp; Category</h3>
	<table id="edit-category-table">
		<tr>
			<td class="invincible" style="width:120px;">Category</td>
			<td class="invincible">
				<select name="category" id="choose-category">
		 			<?php 
		 					foreach ($query as $row) {
		 						echo '<option value="';
		 						print $row->category_id;
		 						echo '">';
		 						print $row->category_name;
		 						echo '</option>';
		 					}
		 			?>
		 			<option value="-1">(new category)</option>
		 		</select>
		 	</td>
		 	<td class="invincible">
    				<p id="newcategory">New Category Name :  <label id="categorylabel"><input id="new-category-form" class="form-control" name="newcategory" type="text" placeholder="New Category Name"/></label></p>
    		</td>
		</tr>
		<tr>
			<td class="invincible">Article Name</td> 
			<td class="invincible">
				<input class="form-control" id="article-name-form" type="text" name="name" required/></td>
		</tr>
	</table>
	</br>

		<!-- ## Deskripsi Kategori ## -->
		<div id="category_desc">
		<h3>Category Description</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsikategori");
		?>
		<br>
		</div>
 		
 		<!-- #### DESCRIPTION #### -->

		<h3>Article Content</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsi");
		?>
		<br>

		<!-- #### TAGGING #### -->
		<h3>Article Tag</h3>
		Pisahkan tag dengan , (koma)
		<ul id="article_tags" name="article_tags">
    		<!-- Existing list items will be pre-added to the tags -->
		</ul>

		<!-- SUBMIT -->
		<button type="submit" class="submit" >Save</button>
	</form>
	
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/css/form.css" />

		<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/tag-it.js"></script>
		<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/local.js"></script>
		<script type="text/javascript" src="<?php echo base_url(); ?>asset/javascript/ckeditor/ckeditor.js"></script>
	</div>
</div>
</body>
</html>