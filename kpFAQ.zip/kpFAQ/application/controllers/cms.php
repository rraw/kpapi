<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CMS extends CI_Controller
{
	function index($article_id = NULL)
	{
		//Menampilkan header
		$this->display_header();

		//menampilkan navigation bar
		$this->display_navigation_bar();

		//menampilkan konten
		$this->display_content($article_id);

		//menampilkan footer
		$this->display_footer();
	}

	public function display_header()
	{
		$this->load->view('cms/cms_header_view');  	
	}

	public function display_navigation_bar()
	{
		//load file model 
		$this->load->model('navigation_bar_model');

		// ambil 
		$data['query_navigation'] = $this->navigation_bar_model->get_category();

		// Menampilkan side navigation bar
		$this->load->view('cms/cms_navigation_bar_view',$data); 

	}

	public function display_content($article_id = NULL)
	{
		$data['article_id'] = $article_id;

		if (!is_null($article_id)) {
			$this->load->model('navigation_bar_model');
			$data['category_id'] = $this->navigation_bar_model->get_categoryid_by_articleid($article_id);
		}
		$this->load->view('cms/cms_main_content',$data);
	}

	public function display_footer()
	{
		$this->load->view('cms/cms_footer_view');
	}

	public function display_category_content($category_id)
	{
		//load modal dan library
		$this->load->library('ckeditor');
		$this->load->model('content_model');
		$this->load->model('navigation_bar_model');

		//atur konfigurasi dari ckeditor yang dimiliki
		$this->ckeditor->basePath = base_url().'asset/javascript/ckeditor/';
		$this->ckeditor->config['toolbar'] = array(
                array( 'Source', '-', 'Bold', 'Italic', 'Underline', 'Format','-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','Image' )
                                                    );
		$this->ckeditor->config['extraAllowedContent'] = 'iframe[*]';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor->config['width'] = '730px';
		$this->ckeditor->config['height'] = '300px';

		//ambil data2 yang dibutuhkan
		$data['content'] = $this->content_model->get_category_content($category_id);
		$data['article'] = $this->navigation_bar_model->get_article_by_categoryid($category_id);
		
		//ambil tag2 dari artikel yang dimiliki
		$data['tag_array'] = array(); $data['query_konten'] = array();
		foreach ($data['article'] as $row) {
			array_push($data['tag_array'], $this->content_model->get_tags_of_article($row->article_id));
			array_push($data['query_konten'], $this->content_model->get_content($row->article_id));
		}

		//gunakan data yang disimpan untuk view2 terkait
		$this->load->view('cms/cms_category_view',$data);
	}

	public function display_article_content($article_id)
	{
		//load modal dan library
		$this->load->library('ckeditor');
		$this->load->model('content_model');
		$this->load->model('article_model');

		//bersihkan id yang dikirim
		$temp = explode('t', $article_id);
		$article_id = $temp[1];

		//atur konfigurasi dari ckeditor yang dimiliki
		$this->ckeditor->basePath = base_url().'asset/javascript/ckeditor/';
		$this->ckeditor->config['toolbar'] = array(
                array( 'Source', '-', 'Bold', 'Italic', 'Underline', 'Format','-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','Image' )
                                                    );
		$this->ckeditor->config['extraAllowedContent'] = 'iframe[*]';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor->config['width'] = '730px';
		$this->ckeditor->config['height'] = '300px'; 

		//variabel id artikel yang ingin ditampilkan
		$data['query_konten'] = $this->content_model->get_content($article_id);
		$data['tag_array'] = $this->content_model->get_tags_of_article($article_id);
		$data['query'] = $this->article_model->get_all_category();

		// Menampilkan konten web berupa deskripsi artikel
		$this->load->view('cms/cms_article_view',$data);
	}

	public function update_article_status(){

		$status = $_POST['status'];
		$temp = explode('t', $_POST['article_id']);
		$article_id = $temp[1];
		
		if ($status == 1) {
			echo "Status konten ini diubah menjadi aktif";
		} else {
			echo "Status konten ini diubah menjadi tidak aktif";
		}

		$this->load->model('article_model');
		$this->article_model->update_article_active_status($article_id, $status);
	}

		public function update_category_status(){

		$active_status = $_POST['status'];
		$category_id = $_POST['category_id'];
		
		if ($active_status == 1) {
			echo "Status konten ini diubah menjadi aktif";
		} else {
			echo "Status konten ini diubah menjadi tidak aktif";
		}

		//load model, terus update deh
		$this->load->model('article_model');
		$this->article_model->update_category_active_status($category_id, $active_status);
	}

	public function edit_rank(){
		//load model
		$this->load->model('navigation_bar_model');
		$data['category'] = $this->navigation_bar_model->get_category();
		
		//load view
		$this->load->view('cms/cms_edit_rank_view', $data);
	}

	public function submit_rank(){

		$this->load->model('content_model');

		foreach ($_POST as $key => $value){
			$kunci = explode("t", $key);
			$this->content_model->update_rank($kunci['1'], $value);
		}
		redirect(base_url()."index.php/cms/");
	}

	public function coba()
	{
		echo $_POST['this'];
		die("adfafaf");
		echo "cihuyy";
	}
}