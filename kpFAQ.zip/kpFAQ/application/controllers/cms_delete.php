<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CMS_delete extends CI_Controller
{
	//langsung database processing
	function delete_article($id = NULL)
	{
		//load model
		$this->load->model('article_model');

		//bersihin variabel id
		$temp = explode('l', $id);
		$id = $temp[1];

		//hapus article, trus cek kalo dia sendirian langsung hapus category 
		if (count($this->article_model->get_all_article_in_category($id))<= 1)
		{	
			$tes = $this->article_model->get_category($id);
			$this->article_model->delete_entry_category($tes['0']->category_id);
		}

		//hapus artikel tersebut
		$this->article_model->delete_entry_article($id);
	}

	function delete_category($id = NULL)
	{
		//load model
		$this->load->model('article_model');
	
		//delete konten
		$this->article_model->delete_entry_category($id);
	}
}