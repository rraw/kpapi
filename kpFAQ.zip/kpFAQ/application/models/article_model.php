<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Article_Model extends CI_Model {

	//get ALL-an
	function get_all_article(){
		$query = $this->db->get('article');
		return $query->result();
	}

	function get_all_category(){
		$query = $this->db->query("SELECT * FROM category WHERE category_status>=0 ORDER BY category_rank");
		return $query->result();
	}

	//insert2an
	function insert_new_entry_article($article_data){
		$this->db->insert('article',$article_data);
		return $this->db->insert_ID();
	}

	function insert_new_entry_content($content_data){
		$this->db->insert('category',$content_data);
		return $this->db->insert_ID();
	}

	function insert_new_entry_category($data){
		$this->db->insert('category',$data);
		return $this->db->insert_ID();
	}

	function insert_tag($tag_name)
	{
		$q = "INSERT INTO tag VALUES ('','".$tag_name."')";
		$result = $this->db->query($q);
		return $this->db->insert_ID();
	}

	function insert_new_mapping($article, $tag)
	{
		$q = "INSERT INTO mapping VALUES ('',".$article.",".$tag.",'1')";
		$result = $this->db->query($q);
	}

	//update2an baru
	function update_entry_article($article_data){
		$this->db->where('article_id',$article_data['article_id']);
		$this->db->update('article',$article_data);
	}

	// Update status article
	function update_article_active_status($article_id, $active_status){
		$query = "UPDATE article SET article_status='" . $active_status. "' WHERE article_id='" . $article_id . "'";
		$query_result = $this->db->query($query);
	}

	// Update status category
	function update_category_active_status($category_id, $active_status){
		$query = "UPDATE category SET category_status='" . $active_status. "' WHERE category_id='" . $category_id . "'";
		$query_result = $this->db->query($query);
	}

	function reset_last_recommendation($cat_id){
		$q = "SELECT article_id FROM article WHERE article_status='127' AND category_id='".$cat_id."'";
		$temp = $this->db->query($q);
		foreach ($temp->result() as $value) {
			$query = "UPDATE article SET article_status='1' WHERE article_id='".$value->article_id."'";
			$this->db->query($query);
		}
	}

	function set_as_recommended($art_id){
		$q = "UPDATE article SET article_status='127' WHERE article_id='".$art_id."'";
		$this->db->query($q);
	}

	//delete2an sesuai peribahan jadi -127 
	function delete_entry_category($category_id){
		$query = "UPDATE category SET category_status='-127' WHERE category_id='" . $category_id . "'";
		$query_result = $this->db->query($query);
	}

	function delete_entry_article($article_id){
		$query = "UPDATE article SET article_status='-127' WHERE article_id='" . $article_id . "'";
		$query_result = $this->db->query($query);
	}

	function delete_entry_tag($article_id){	
		$query = "UPDATE mapping SET mapping_status='-127' WHERE article_id='" . $article_id . "'";
		$query_result = $this->db->query($query);
	}

	//ambil article, category, dan parameter yang spesifik
	function get_article($id){
		$query = "SELECT * FROM article INNER JOIN category ON article.category_id=category.category_id WHERE article_id =".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_category($id){
		$query = "SELECT category_id FROM article WHERE article_id=".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_all_article_in_category($id)
	{	
		$temp =	$this->get_category($id);
		$category_id = $temp['0']->category_id;
		$query = "SELECT * FROM article WHERE category_id=".$category_id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_tag_by_name($name)
	{
		$q = "SELECT tag_id FROM tag WHERE tag_name ='".$name."'";
		$result = $this->db->query($q);
		return $result->result();
	}

	function get_last_category_rank()
	{
		$maxid = 0;
		$row = $this->db->query('SELECT MAX(category_rank) AS `maxid` FROM `category`')->row();
		if ($row) {
    		$maxid = $row->maxid; 
		}
		return $maxid;
	}

	//checking
	function is_tag_exists($tag_name)
	{
		$q = "SELECT * FROM tag WHERE tag_name='".$tag_name."'";
		$result = $this->db->query($q);
		return $result->result();
	}
}