<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/

class Login_model extends CI_Model
{
	function get_username_password($data = null)
	{
		$username = $data['username'];
		$password = $data['password'];
		$query = "SELECT username,password FROM member_account WHERE username ='".$username."' AND password ='".$password."' AND role = 'admin'";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
}

?>