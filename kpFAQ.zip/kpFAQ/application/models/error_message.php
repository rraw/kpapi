<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!DOCTYPE HTML>

<html>
<head>
	<title>Forbidden Access</title>
	<!-- FAVICON --> 
	<link href="base_url();asset/img/favicon.ico" rel="shortcut icon" type="icon">
	<link rel="stylesheet" type="text/css" href="base_url();asset/css/login_style.css">
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
</head>
<body>
<div class="container">
	<img src="base_url();asset/img/logo_tiket.png">
	<h1>Forbidden Access</h1>
	<p>The page you request is forbidden. </br> Please go back to home page.</p>
<script type="text/javascript">
	$(document).ready(function()
	{
		$("h1").click(function(){
			window.location.replace("base_url();");
			// body...
		});
	});
</script>
	<button id ="home">Continue</button>
</div>
</body>
<script type="text/javascript" src="<?php echo base_url(); ?>asset/js/login_logout.js"></script>
</html>


