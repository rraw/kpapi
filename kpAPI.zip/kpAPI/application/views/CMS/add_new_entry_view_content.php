<div id="API-content">
	<div class="main">

	<!-- baru -->
	<form action="http://localhost/kpAPI/add_new_entry/insert_content" method="POST">

		<!-- ##### API NAME & CATEGORY ##### -->
		<h2>New Content</h2>
		<!-- <h3>Content Name</h3> -->
		<table id="edit-category-table">
		<tr>
			<td class="invincible" style="width:150px;">Content Name</td> 
			<td class="invincible">:
				<input class="form-control" id="api-name-form" type="text" name="name" /></td>
		</tr>
		</table>
		</br>
 		
 		<!-- #### DESCRIPTION #### -->

		<h3>Deskripsi Konten</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsi");
		?>
		
		<br>
		<button type="submit" class="submit" >Save</button>
	</form>
	
		<link rel="stylesheet" type="text/css" href="http://localhost/kpAPI/asset/css/form.css" />

 		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
		<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<script src="http://localhost/kpAPI/asset/js/local.js"></script>
		<script src="http://localhost/kpAPI/asset/js/ckeditor/ckeditor.js"></script>
	</div>
</div>
