<div id ="API-content">

<div class="main">
	<!-- DESKRIPSI -->
	<!-- ############ API DESCRIPTION SECTION ##########-->



	<?php	
			foreach ($query_deskripsi as $rows) 
			{

				echo "<h2>";
				print $rows->API_name;
				echo "</h2>";
				// echo '<div class="edit_api">';
				echo '<form method="" class="form-hid1" action="http://localhost/kpAPI/API_admin/update_entry/'.$rows->API_id.'">';
	?>			
				<!-- Edit Button -->
				<button type="submit" value="Edit" id="editAPI">Edit</button>
				
				<!-- Delete Button -->
				<button value="delete" type="button" id="deleteAPI">Delete</button>

				<!-- active status -->
				<button value="active" type="button" id="api-status-btn">Active</button>


	<?php
				echo '<input type="hidden" id="API_id" value="'.$rows->API_id.'">';
				echo '<input type="hidden" id="API_name" value="'.$rows->API_name.'">';

				echo "</br>";
				$text= $rows->API_description;
				echo "<p>$text</p>";
				echo "</br>";

				echo "<h3>Input URL</h3></br><p>";
				print $rows->API_input;
				echo "</p>";

			}
 	 ?>

<!-- ############ TABEL PARAMETER DAN INPUT ############### -->
 	<!-- API PARAMETER -->
	<h3>Parameter</h3></br>
	<table>			
		<!-- table heading -->
		<thead>
		<tr>
			<th>Parameter Name</th>
			<th>Parameter Description</th>
			<th>Parameter Format</th>
			<th>Parameter Default</th>
			<th>Parameter Mandatory</th>
			<th>Input</th>
		</tr>
		</thead>
		<!-- table body -->
		<tbody>
			<?php	
				foreach ($query_parameter as $row) 
				{
				echo "<tr>";
				echo "<td>";
					print $row->parameter_name;
				echo "</td>";

				echo "<td>";
					print $row->parameter_description;
				echo "</td>";

				echo "<td>";
					print $row->parameter_format;
				echo "</td>";

				echo "<td>";
					print $row->parameter_default;
				echo "</td>";

				echo "<td>";
					print $row->parameter_mandatory;
				echo "</td>";				
			?>

			<!-- INPUT PARAMETER -->
			<td>
				<div class="input-group">
				
<?php if (strcasecmp( $row->parameter_name, "Token" )>=0) 
	{
		echo "<input type=\"text\" class=\"form-control\" id=\"".$row->parameter_name."\" ";
		echo "value=";
		print_r($token);
	} else
	{
?>
	<input type="text" class="form-control" id="<?php echo $row->parameter_name;?>"
<?php
	}
?>
					>
				</div>
			</td>

		</tr>

		<?php
				}
		 ?>

		 <!-- FOOTER TABEL -->
 		<tr>
 			<td>Output_type</td>
 			<td>Tipe output yang diinginkan</td>
 			<td>bebas</td>
 			<td>XML</td>
 			<td>TRUE</td>
 			<td> 				
 				<select id="choose-button">
 					<option value="xml">XML</option>
				  	<option value="json">JSON</option>
				  	<option value="array">Array</option>
				  	<option value="serialized format">Serialized Format</option>
				</select>
 			</td>
 		</tr>
 		<tr>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible">
	 			<!-- Submit Button -->
	 			<div class = "submit-button">
					<button type="button" class="submit" id="sbmt">Submit</button>
				</div>
			</td>
 		</tr>
 		</tbody>
			</table>

<!-- END OF FORM -->

<!-- END OF TABLE_DIV -->

		<script type="text/javascript">

		$(".output").hide(); 

		$("#sbmt").click(function(){

	        //variabel untuk menyimpan inputan user
	        <?php 
	            foreach ($query_parameter as $row) {
	                echo "var " . $row->parameter_name . " = $('#" . $row->parameter_name . "').val();";
	            }
	         ?>

	        var input_url = "<?php echo $rows->API_input; ?>";
	        var output = $('#choose-button').val()

	        //form post
	        $.post("http://localhost/kpApi/index.php/api/parameter_form/",
	        {
	            
	            input_url:input_url,
	            <?php 
	                // looping kiriman post
	                foreach ($query_parameter as $row) {
	                    echo $row->parameter_name . ":" . $row->parameter_name . "," ;
	                }//end of reach
	            ?>
	            output:output,

    		},

	        function(data,status)
	        {   
	            $(".output").html(data);     
	            $(".output").show();   
	            $("body").animate(
			        { 
			            scrollTop:$(".output").offset().top-50
			        },600 );
	        });

		});//end of clik sbmt
		</script>

	<!-- ########### OUTPUT SECTION ###########-->

	<div class="output">
		
	</div>


<!-- end of main -->
</div>
		
</div>
<!-- </div>	 -->
</div>
<!-- end of container -->
</div>
<script src="http://localhost/kpAPI/asset/js/delete.js"></script>

<script type="text/javascript">
		var id = <?php echo $rows->API_id; ?>;
		var active = "1";
		var inactive = "0";
		var status = <?php echo $rows->api_active_status; ?>;

		console.log(status);

		//menampilkan active/inactive
		if (status == 1) {
			$("#api-status-btn").val("active");
			$("#api-status-btn").html("Activated");
			$("#api-status-btn").addClass("status-active");
		} else {
			$("#api-status-btn").val("inactive");
			$("#api-status-btn").html("Deactivated");
		}


		$("#api-status-btn").click(function(){
			//action dari button status
			if ($(this).val() == "active"){
				$(this).html("Deactivated");
				$(this).val("inactive");
				$("#api-status-btn").removeClass("status-active");
				$.post("http://localhost/kpApi/index.php/api_admin/update_api_status/",
		        {
		            
		            api_id: id,
		            status: inactive
	    		},

		        function(data,status)
		        {   
		            alert(data);        
		        });
			} else {
				$("#api-status-btn").addClass("status-active");
				$("#api-status-btn").html("Activated");
				$(this).val("active");
				$.post("http://localhost/kpApi/index.php/api_admin/update_api_status/",
		        {
		            api_id: id,
		            status: active
	    		},

		        function(data,status)
		        {   
		            alert(data);        
		        });
			}//endif
		});

	</script>

