<div id="API-content">
	<div class="main">
	<form action="http://localhost/kpAPI/index.php/API_admin/update_data" method="POST">


	<!-- ##### API NAME & CATEGORY ##### -->
	<h2>Edit Content</h2>

	<h3>API Name &amp; Category</h3>
	<table id="edit-category-table">
		<tr>
			<td class="invincible" style="width:150px;">Category Name</td>
 			<td class="invincible">:
		 		<select name="category" id="choose-category">
		 			<?php
		 					foreach ($query as $row) {
		 						echo '<option value="';
		 						print $row->category_id;
		 						echo '" ';
		 						if ($API['0']->category_id==$row->category_id) {
		 							echo "selected=\"selected\"";
		 						}
		 						echo '">';
		 						print $row->category_name;
		 						echo '</option>';
		 					}
		 			?>
		 			<option value="-1">(new category)</option>
		 		</select>
		 	</td>
		 	
		 </tr>
		 <tr class="invincible" id="newcategory">
		    		<td class="invincible">New Category Name</td>
		    		<td class="invincible">:
		    			<input id="new-category-form" name="newcategory" type="text" placeholder="New Category Name" class="form-control"/>
		    		</td>
		 </tr>

 		<tr>

 			<td class="invincible">API Name</td>
 			<td class="invincible">:
 				<input type="text" name="name" placeholder ="API Name"class="form-control" id="api-name-form" <?php echo 'value="'; print $API['0']->API_name; echo'"'; ?>/></td>
 		</tr>
 	</table>
 	<br>
		
		<!-- ## Deskripsi Kategori ## -->
		<div id="category_desc">
		<h3>Category Description</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsikategori");
		?>
		<br>
		</div>
		
		<!-- #### DESCRIPTION #### -->
 		<h3>API Description</h3>

		<?php  
			echo $this->ckeditor->editor("deskripsi",$API['0']->API_description);
			echo '<input type="hidden" name="API_id" value="'.$API['0']->API_id.'">';
		?>
		
		<!-- #### API PARAMETER ####-->

		<h3>API Parameter</h3>
		<fieldset id="parameter-form" name="parameter">
	    	<table id="parameter-table">
	    		<thead>
	    		<tr>
		    		<th>Parameter Name</th>
		   			<th>Parameter Description</th>
	  				<th>Parameter Format</th>
	   				<th>Parameter Default</th>
		    		<th>Parameter Mandatory</th>
		    		<th class="invincible"></th>
    			</tr>
    			</thead>

	    		<?php
	    			$i = 1;
	    			foreach ($parameter as $row){ 
	    				echo "<tr>";
	    				echo '<div class="fieldwrapper" id="field'.$i.'">';
	    				echo '<td><input type="text" class="fieldname" name="name'.$i.'" value="'.$row->parameter_name.'"></td>';
	    				echo '<td><textarea class="fielddescription" name="description'.$i.'" value="'.$row->parameter_description.'"></textarea></td>';
	    				// echo '<td><input type="text" class="fielddescription" name="description'.$i.'" value="'.$row->parameter_description.'"></td>';
	    				echo '<td><input type="text" class="fieldformat" name="format'.$i.'" value="'.$row->parameter_format.'"></td>';
	    				echo '<td><input type="text" class="fielddefault" name="default'.$i.'" value="'.$row->parameter_default.'"></td>';
	    				echo '<td><select class="fieldmandatory" name="mandatory'.$i.'">';
	    					echo '<option value="TRUE"'; if($row->parameter_mandatory=='TRUE'){ echo ' selected';} echo '>TRUE</option>';
	    					echo '<option value="FALSE"'; if($row->parameter_mandatory=='FALSE'){ echo ' selected';} echo '>FALSE</option>';
	    				echo '</select></td>';
	    				if ($i!=1) {
	    					echo '<td class="invincible"><button type="button" class="delete-button remove" value="Delete">X</button></td>';
	    				}
	    				echo '</div>';
	    				echo "</tr>";

	    				$i++;
	    			}
	    		?>	
	
	    	</table>

	    	<div id="add-div">
	    	<input type="button" value="Add a field" class="btn btn-default add" id="add" />
	    	</div>
		</fieldset>
		

		<!-- #### LINK INPUT #### -->
		<br>
		<h3>URL Input</br></h3>  
		<div class="input-group">
			<input style="width:700px; height:50px;border-radius:5px;"type="text" class="form-control" name="input" <?php echo 'value="'; print $API['0']->API_input; echo'"'; ?>>
  			<!-- <input type="text" class="form-control" placeholder="Username"> -->
		</div>
		
		<br>
 		<button type="submit" class="submit">Save</button>
	</form>

		<link rel="stylesheet" type="text/css" href="http://localhost/kpAPI/asset/css/form.css" />

 		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
		<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<script src="http://localhost/kpAPI/asset/js/local.js"></script>
		<script src="http://localhost/kpAPI/asset/js/ckeditor/ckeditor.js"></script>
		
	
	</div>
</div>