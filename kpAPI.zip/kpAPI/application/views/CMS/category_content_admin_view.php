<div id="API-content">
<div class="main">

	<h2>
	<?php 
		foreach ($content as $row) {
			echo $row->category_name;
		
	?>
	</h2>

	<?php  
			echo '<form action="http://localhost/kpAPI/API_admin/update_content/'.$row->category_id.'">';
			echo '<input type="hidden" id="category_id" value="'.$row->category_id.'">';
			echo '<input type="hidden" id="category_name" value="'.$row->category_name.'">';
		
	?>
	<!-- Edit Button -->
	<button type="submit" value="Edit" id="editcategory"> Edit</button>
	
<?php  

		echo "<button value=\"delete\" type=\"button\" id=delete".$row->category_type.">Delete</button>";
?>

	<!-- Status Button -->
	<button value="active" type="button" id="category-status">Active</button>

	<!-- script for update category status active/inactive -->

	<script type="text/javascript">

		var id = <?php echo $row->category_id; ?>;
		var active = "1";
		var inactive = "0";
		var status = <?php echo $row->category_active_status; ?>;

		if (status == 1) 
		{
			$("#category-status").val("active");
			$("#category-status").html("Activated");
			$("#category-status").addClass("status-active");
		} else {
			$("#category-status").val("inactive");
			$("#category-status").html("Deactivated");
		};

		$("#category-status").click(function(){

			if ($(this).val() == "active"){
				
				$(this).html("Deactivated");
				$(this).val("inactive");
				$(this).removeClass("status-active");
				$.post("http://localhost/kpApi/index.php/api_admin/update_category_status/",
		        {
		            
		            category_id: id,
		            status: inactive
	    		},

		        function(data,status)
		        {   
		            alert(data);        
		        });
				

			} else {
				
				$("#category-status").addClass("status-active");
				$("#category-status").html("Activated");
				$(this).val("active");
				$.post("http://localhost/kpApi/index.php/api_admin/update_category_status/",
		        {
		            
		            category_id: id,
		            status: active
	    		},

		        function(data,status)
		        {   
		            alert(data);        
		        });
		
			}//endif
		});

	</script>

	<p>
	<?php 
		
			echo $row->category_content;
			
		}
	?>
	</p>
	<script type="text/javascript" src="http://localhost/kpAPI/asset/js/delete.js"></script>
</div>
</div>

</div>
</div>


