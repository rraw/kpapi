<div id="API-content">
	<div class="main">
	<!-- baru -->
	<form action="http://localhost/kpAPI/add_new_entry/insert_data" method="POST">
	<!-- ##### API NAME & CATEGORY ##### -->
	<h2>New API</h2>
	<h3>API Name &amp; Category</h3>
	<table id="edit-category-table">
		<tr>
			<td class="invincible" style="width:150px;">Category Name</td>
			<td class="invincible">:
				<select name="category" id="choose-category">
		 			<?php 
	 					foreach ($query as $row) 
	 					{
	 						echo '<option value="';
	 						print $row->category_id;
	 						echo '">';
	 						print $row->category_name;
	 						echo '</option>';
	 					}
		 			?>
		 			<option value="-1">(new category)</option>
		 		</select>
		 	</td>
		</tr>
		<tr class="invincible" id="newcategory">
		    		<td class="invincible">New Category Name</td>
		    		<td class="invincible">:
		    			<input id="new-category-form" name="newcategory" type="text" placeholder="New Category Name" class="form-control"/>
		    		</td>
		 </tr>
		<tr>
			<td class="invincible">API Name</td> 
			<td class="invincible">:
				<input class="form-control" id="api-name-form" type="text" name="name" /></td>
		</tr>

	</table>
	</br>

		<!-- ## Deskripsi Kategori ## -->
		<div id="category_desc">
		<h3>Category Description</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsikategori");
		?>
		<br>
		</div>
 		
 		<!-- #### DESCRIPTION #### -->
		<h3>API Description</h3>
		<?php  
			echo $this->ckeditor->editor("deskripsi");
		?>
		<br>
		<!-- #### API PARAMETER ####-->
		<h3>API Parameter</h3>

		<fieldset  id="parameter-form"name="parameter">
    		<table id="parameter-table">
    			<thead>
    			<tr>
		    		<th>Parameter Name</th>
		   			<th>Parameter Description</th>
	  				<th>Parameter Format</th>
	   				<th>Parameter Default</th>
		    		<th>Parameter Mandatory</th>
		    		<th class="invincible"></th>
    			</tr>
    			</thead>
    			<tr>
    			
        		<div class="fieldwrapper" id="field2"/>
	       			<td><input type="text" class="fieldname" name="name1"/></td>
	       			<td><textarea class="fielddescription" name="description1"></textarea></td>
	        		<td><input type="text" class="fieldformat" name="format1"/></td>
	        		<td><input type="text" class="fielddefault" name="default1"/></td>
	      			<td><select class="fieldmandatory" name="mandatory1"><option value="TRUE">TRUE</option><option value="FALSE">FALSE</option></select></button></td>
	        		<td class="invincible" style="color:white;">Kosong</td>
       			</tr>
    		</table>
    		<!-- add field button -->
    		<button type="button" value="Add a field" id="add" class="add">Add a field</button>
		</fieldset>
		
		<!-- #### LINK INPUT #### -->
		<h3>URL Input</br></h3> 
		<div class="input-group">
			<input id ="input-form" style="width:700px; height:40px;border-radius:5px;"type="text" class="form-control" name="input">
		</div>
		<br>
		<button type="submit" class="submit"id="submit-API" >Save</button>
	<!-- </form> -->
		<link rel="stylesheet" type="text/css" href="http://localhost/kpAPI/asset/css/form.css" />
 		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
		<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<script src="http://localhost/kpAPI/asset/js/local.js"></script>
		<script src="http://localhost/kpAPI/asset/js/ckeditor/ckeditor.js"></script>
	</div>
</div>
