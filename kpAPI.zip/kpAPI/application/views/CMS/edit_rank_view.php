<div class="main">

<h2>Edit Category Rank</h2>

<table class="edit-rank">
<thead>
	<tr>
	<th>Category Name</th>
	<th>Edit Rank</th>
	</tr>
</thead>




<?php 
	//bikin input text
	foreach ($category as $row) {

		echo "<tr>";
		echo "<td>";
		echo $row->category_name;
		echo "</td>";
		echo "<td>";
		echo "<input type='text' id='cat". $row->category_id ."' value='". $row->category_rank ."'><br>";
		echo "</td>";
		echo "</tr>";
	}

 ?>
<tr>
<td class="invincible"></td>
<td class="invincible"><button id='submit_rank' class="submit">Save</button></td>
</tr>

</table>




<script type="text/javascript">
	
	$("#submit_rank").click(function(){

	
		<?php 
	            foreach ($category as $row) {
	                echo "var cat" . $row->category_id . " = $('#cat" . $row->category_id . "').val();";
	            }
	         ?>

		$.post( "http://localhost/kpApi/index.php/api_admin/submit_rank/", 
			{
	
				 <?php 
	                // looping kiriman post
	                foreach ($category as $row) {
	                    echo "cat" . $row->category_id . ": cat" . $row->category_id . "," ;
	                }//end of reach
	            ?>
			}, 

			function( data ) {
			alert( "Data has been saved successfully!" + data );
			window.location.replace("http://localhost/kpAPI/index.php/API_admin");

			});

		//load navigatio panel dan konten
		



	});
</script>

</div>