<div id="API-content">
	<div class="main">
	<form action="http://localhost/kpAPI/index.php/API_admin/update_content_data" method="POST">


	<!-- ##### API NAME & CATEGORY ##### -->
	<h2>Edit Content</h2>
	<table id="edit-category-table">
		<tr>
			<td class="invincible" style="width:160px;">Content Name</td> 
			<td class="invincible">:
				<input class="form-control" id="api-name-form" type="text" name="name" <?php echo 'value="'; print $content['0']->category_name ;echo '"' ?>/></td>
		</tr>
	</table>
		</br>
		
		<!-- #### DESCRIPTION #### -->
 		<h3>Description</h3>

		<?php  
			echo $this->ckeditor->editor("deskripsi",$content['0']->category_content);
			echo '<input type="hidden" name="category_id" value="'.$content['0']->category_id.'">';
		?>		

		<br>
 		<button type="submit" class="submit">Save</button>
	</form>

		<link rel="stylesheet" type="text/css" href="http://localhost/kpAPI/asset/css/form.css" />

 		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
		<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<script src="http://localhost/kpAPI/asset/js/local.js"></script>
		<script src="http://localhost/kpAPI/asset/js/ckeditor/ckeditor.js"></script>
		
	
	</div>
</div>