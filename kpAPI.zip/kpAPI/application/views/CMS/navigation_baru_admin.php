<div class="main-content">

<div class="side">
<div class="inside">

<div class="button-group" id="add-content">
<div class="main-btn">
<h2> + New Content</h2>
</div>
<div class="sub-btn"><a>
        <form method="" class="form-hid2" action="http://localhost/kpAPI/add_new_entry/new_content">
            <button class="menuadd" value="Add New" type="submit" id="add-content">Add Content</button>
        </form></a>
</div>
<div class="sub-btn"><a>
        <form method="" class="form-hid2" action="http://localhost/kpAPI/add_new_entry">
            <button class="menuadd" value="Add New" type="submit" id="add-api">Add API</button>
        </form></a>
</div>
</div>
    <!-- button untuk edit rank -->
    <button id="edit_rank_button" class="button-group"><h2>Edit Category Rank</h2></button>
    
    <!-- ########### BAGIAN LOOP KATEGORI###########-->
<?php 

// Row adalah sebuah array yang menyimpan nama kategori dan id kategori 
foreach ($query_navigation as $row) {
    static $count = 1;
    $type = $row->category_type;
    $content = $row->category_content;
    //ambil nama kategori
   $category_name = $row->category_name;
   //ambil id kategori
   $category_id = $row->category_id;
        
?>
    <!-- Creating Category -->
    <div class="trigger b" id="<?php echo $category_id; ?>">
        <?php 
        if ($type=='category') 
        {
        echo "<span class=\"trigger-span\"></span>";
        } ?>
        <a href="#" id="<?php echo $category_id; ?>">
        <?php 
            echo str_pad($count,2,"00",STR_PAD_LEFT);
            echo " ";
            print $category_name;
            $count=$count+1;

        ?>
    </a>
    </div>

<!-- UNTUK YANG BERTIPE  -->
<?php 
    
    if ($type=='category') 
    {
            echo "<div class=\"toggle_container\" style=\"display: none;\">";
            echo "<ul>";
            
            $this->load->model('navigation_bar_model');
            // ambil tipe kategori

            $data = $this->navigation_bar_model->get_api_by_categoryid_sort_by_name($category_id);
            // LOOPING api di kategori yang sedang di looop
            foreach ($data as $r){     
?>
        <!-- Giving name for each api in category -->
        <li><a class="anchor" id="<?php echo "api";echo $r->API_id ?>">
            <?php print $r->API_name;?>
        </a></li>

        <script type="text/javascript"> 
            $(document).ready(function(){
                //ID Kategori
                var category_id = "#<?php echo 'kat'; echo $row->category_id; ?>";
                //ID Sub kategori
                var api_id = "#<?php echo 'api'; echo $r->API_id; ?>";

                //State awal navigation bar
                var id = "<?php echo  $r->API_id; ?>";   
                $(api_id).click(function()
                {
                    $.post("http://localhost/kpAPI/index.php/API/check_session/",function(data)
                    {
                        if (data) 
                        {
                            // logged in
                            $('#API-content').
                    load('http://localhost/kpAPI/index.php/API_admin/display_apicontent/'+id);
                        } else
                        {
                            // not logged in
                            alert("Please Log In to Continue");
                            window.location.replace("http://localhost/kpAPI/");
                        };
                    });
                });
            });
        </script>

        <?php 
            }//END OF FOR EACH $data buat child
        ?>
        </ul></div>
    
<?php
} // End of if for api-type category 
} // END OF CATEGORYLOOPING
?>

<!-- end of inside -->
</div>
<!-- end of side -->
</div>