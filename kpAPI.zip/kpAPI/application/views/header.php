<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!DOCTYPE HTML>

<html>
	<head>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

		<title>tiket.com API docs</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />

		<!-- FAVICON --> 
		<link href="http://localhost/kpAPI/asset/img/favicon.ico" rel="shortcut icon" type="icon">

		<!-- FONT -->
		<link href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet" type="text/css">

   		<!-- JAVASCRIPT-->
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.4.min.js"></script>

    	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>

		<script type="text/javascript" src="http://localhost/kpAPI/asset/js/expandcollapse.js"></script>
		
		<script type="text/javascript" src="http://localhost/kpAPI/asset/js/login_logout.js"></script>
    	
    	<!-- CSS --> 
		<link type="text/css" rel="stylesheet" href="http://localhost/kpAPI/asset/css/style.css">

	</head>

	<!--  #################### BODY ####################-->

	<body onload="prettyPrint()">

		<!-- HEADER -->
		<!-- ********************************************************* -->
		<div class="container">
			<header>
				<p style="margin-right : 15px;"><a>welcome back, <b><?php echo $username; ?></b></a> | <a class="log-out">Log Out</a></p>
				<a href="#"><img src="http://localhost/kpAPI/asset/img/logo_tiket.png" width="232" height="49"></a>
				<div class="clear"></div>
			</header>
			<div class="head">
				<h2>Welcome to</h2>
				<h1>API Documentation</h1>
			</div>



