

<div class="main-content">
<div class="side">
<div class="inside" >



    <!-- ########### BAGIAN LOOP KATEGORI###########-->
<?php 

// Row adalah sebuah array yang menyimpan nama kategori dan id kategori 
foreach ($query_navigation as $row) {
    static $count = 1;
    $type = $row->category_type;
    //ambil nama kategori
   $category_name = $row->category_name;
   //ambil id kategori
   $category_id = $row->category_id;
        
?>
    <!-- Creating Category -->
    <div class="trigger a" id="<?php echo $category_id; ?>">
        <?php 
        if ($type=='category') 
        {
        echo "<span class=\"trigger-span\"></span>";
        } ?>
        <a href="#" id="<?php echo $category_id; ?>">
        <?php 
            echo str_pad($count,2,"0",STR_PAD_LEFT);
            echo " ";
            print $category_name;
            $count=$count+1;
        ?>
    </a>
    </div>

<!-- UNTUK YANG BERTIPE API -->
<?php 
    
    if ($type=='category') 
    {
            echo "<div class=\"toggle_container\" style=\"display: none;\">";
            echo "<ul>";
            
            $this->load->model('navigation_bar_model');
            // ambil tipe kategori

            $data = $this->navigation_bar_model->get_active_api_by_categoryid_sort_by_name($category_id);
            // LOOPING api di kategori yang sedang di looop
            foreach ($data as $r){     
        ?>
        <!-- Giving name for each api in category -->
        <li><a class="anchor" id="<?php echo "api";echo $r->API_id ?>">
            <?php print $r->API_name;?>
        </a></li>

        <script type="text/javascript"> 
            $(document).ready(function(){
                //ID Kategori
                var category_id = "#<?php echo 'kat'; echo $row->category_id; ?>";
                //ID Sub kategori
                var api_id = "#<?php echo 'api'; echo $r->API_id; ?>";

                //State awal navigation bar
                var id = "<?php echo  $r->API_id; ?>";

                $(api_id).click(function()
                {
                    $.post("http://localhost/kpAPI/index.php/API/check_session/",function(data)
                    {
                        if (data) 
                        {
                            // logged in
                            $('#API-content').
                            load('http://localhost/kpAPI/index.php/API/display_apicontent/'+id);
                        } else
                        {
                            alert("Please Log In to Continue");
                            window.location.replace("http://localhost/kpAPI/");
                        };
                    });
                });
            });
        </script>

        <?php 
            }//END OF FOR EACH $data buat child
        ?>
        </ul></div>

    
<?php
} // End of if for api-type category 
} // END OF CATEGORYLOOPING
?>
                
<!-- end of inside -->
</div>
<!-- end of side -->
</div>

