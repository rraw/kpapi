
<div class="main">
	<?php	
		foreach ($query_deskripsi as $rows) 
		{
			echo "<h2>";
			print $rows->API_name;
			echo "</h2></br>";

			echo "<h3>Description : </h3></br>";
			$text= $rows->API_description;
			echo "<p>$text</p>";
			echo "</br>";

		}
 	 ?>
 	 
 	<!-- API PARAMETER -->
	<h3>Parameter</h3></br>
	<table>			
		<!-- table heading -->
		<thead>
		<tr>
			<th>PARAMETER NAME</th>
			<th>PARAMETER DESCRIPTION</th>
			<th>PARAMETER FORMAT</th>
			<th>PARAMETER DEFAULT</th>
			<th>PARAMETER MANDATORY</th>
			<th>INPUT</th>
		</tr>
		</thead>
		<!-- table body -->
		<tbody>
		<?php	
			foreach ($query_parameter as $row) {
			echo "<tr>";
			echo "<td>";
				print $row->parameter_name;
			echo "</td>";

			echo "<td>";
				print $row->parameter_description;
			echo "</td>";

			echo "<td>";
				print $row->parameter_format;
			echo "</td>";

			echo "<td>";
				print $row->parameter_default;
			echo "</td>";

			echo "<td>";
				print $row->parameter_mandatory;
			echo "</td>";				
		?>

			<!-- INPUT PARAMETER -->
			<td>
				<div class="input-group">
				
<?php if (strcasecmp( $row->parameter_name, "Token" )>=0) 
	{
		echo "<input type=\"text\" class=\"form-control\" id=\"".$row->parameter_name."\" ";
		echo "value=";
		print_r($token);
		echo " readonly";
	} else
	{
?>
	<input type="text" class="form-control" id="<?php echo $row->parameter_name;?>"
<?php
	}
?>
					>
				</div>
			</td>
		</tr>

		<?php
				}
		 ?>

		 <!-- FOOTER TABEL -->
 		<tr>
 			<td>Output_type</td>
 			<td>Tipe output yang diinginkan</td>
 			<td>bebas</td>
 			<td>XML</td>
 			<td>TRUE</td>
 			<td> 				
 				<select id="choose-button">
 					<option value="xml">XML</option>
				  	<option value="json">JSON</option>
				  	<option value="array">Array</option>
				  	<option value="serialized format">Serialized Format</option>
				</select>
 			</td>
 		</tr>
 		<tr>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible"></td>
	 		<td class="invincible">
	 			<!-- Submit Button -->
	 			<div class = "submit-button">
					<button type="button" class="submit" id="sbmt">Submit</button>
				</div>
			</td>
 		</tr>
 		</tbody>
			</table>

<!-- END OF FORM -->

<!-- END OF TABLE_DIV -->

		<script type="text/javascript">
		$(".output").hide();

		$("#sbmt").click(function(){

	        //variabel untuk menyimpan inputan user
	        <?php 
	            foreach ($query_parameter as $row) {
	                echo "var " . $row->parameter_name . " = $('#" . $row->parameter_name . "').val();";
	            }
	         ?>

	        var input_url = "<?php echo $rows->API_input; ?>";
	        var output = $('#choose-button').val()

	        //form post
	        $.post("http://localhost/kpApi/api/parameter_form/",
	        {
	            input_url:input_url,
	            <?php 
	                // looping kiriman post
	                foreach ($query_parameter as $row) {
	                    echo $row->parameter_name . ":" . $row->parameter_name . "," ;
	                }//end of reach
	            ?>
	            output:output,

    		},

	        function(data,status)
	        {   
	            $(".output").html(data);     
	            $(".output").show();   
	            $("body").animate(
			        { 
			            scrollTop:$(".output").offset().top-20
			        },600 );
	        });

	        //show class output dibawah

	   

		});//end of clik sbmt
		</script>

	<!-- ########### OUTPUT SECTION ###########-->

	<div class="output">
			
	</div>

<!-- end of main -->
</div>
<script type="text/javascript" src="http://localhost/kpAPI/asset/js/pop-up.js"></script>

