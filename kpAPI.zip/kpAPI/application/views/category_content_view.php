<div id="API-content">
<div class="main">

	<h2>
	<?php 
		foreach ($content as $row) {
			echo $row->category_name;
		}
	?>
	</h2>
	<p>
	<?php 
		foreach ($content as $row) {
			echo $row->category_content;
		}
	?>
	</p>

</div>
</div>

</div>
</div>