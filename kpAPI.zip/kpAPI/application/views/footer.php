
	<footer>
	<p>&copy; 2014 PT. Global Tiket Network. All Rights Reserved.</p>
	</footer>
<body>
</html>
