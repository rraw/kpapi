<html>
<head>
	<title></title>
</head>
<body>
Login succeed
</br>
Username : <?php echo $query_result[0]->account_username;?>
</br>
Password :	<?php echo $query_result[0]->account_password;?>
</body>
</html>