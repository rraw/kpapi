<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Add_New_Entry extends CI_Controller {
	public function index($id = NULL) 
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		// checking session
		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin

				//load library, model, helper
				$this->load->library('ckeditor');
				$this->load->model('API_model');

				//atur konfigurasi dari ckeditor yang dimiliki
				$this->ckeditor->basePath = base_url().'asset/js/ckeditor/';
				$this->ckeditor->config['toolbar'] = array(
		                array( 'Source', '-','Bold', 'Italic', 'Underline', '-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','-','Image','Heading')
		                                                    );

				$this->ckeditor->config['language'] = 'en';
				$this->ckeditor->config['width'] = '730px';
				$this->ckeditor->config['height'] = '300px';   

				//ambil data category dan tampilkan view
				$data['query'] = $this->API_model->get_all_category();
				$name['username'] = $data['username'];
				$this->display_header();
				$this->display_navigation_bar();
				$this->load->view('CMS/add_new_entry_view_API',$data);
			} else {
				// jika bukan admin maupun sudah login
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}

	//session session an
	public function retrieve_session()
	{
		$data = $this->session->all_userdata();
		return $data;
	}

	public function log_out()
	{
		$this->load->library('session');
		$this->session->sess_destroy();
	}

	public function redirect_error_page()
	{
		redirect("http://localhost/kpAPI/login/forbidden_access");
	}

	public function display_header()
	{	
		$this->load->library('session');
		$data = $this->retrieve_session();
		$name['username'] = $data['username'];
		$this->load->view('CMS/header_cms',$name);  	
	}

	public function insert_data()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		
		// checking session
		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin
				//load model
				$this->load->model('API_model');
				
				//ambil data-data dari post
				$category = $_POST['category']; $newcategory = $_POST['newcategory']; $category_desc = $_POST['deskripsikategori'];
				$name = $_POST['name']; $description = $_POST['deskripsi']; $input = $_POST['input'];
				
				//kalo category baru, masukin ke tabel category dulu, trus IDnya masukin ke $category
				if ($newcategory != '') {
					$rank =  $this->API_model->get_last_category_rank() + 1;
					$category_data = array(
						'category_name' 	=> "$newcategory",
						'category_rank'		=> "$rank",
						'category_type' 	=> 'API',
						'category_content'	=> "$category_desc"
					);
					$category =  $this->API_model->insert_new_entry_category($category_data);
				}
				
				//buat array untuk input data ke tabel API dan input sekalian
				$api_data = array(
					'API_id'			=> '',
					'API_name'			=> "$name",
					'API_description'	=> "$description",
					'API_input'			=> "$input",
					'category_id'		=> "$category"
				);
				$API_id = $this->API_model->insert_new_entry_API($api_data);

				//siapkan repetisi untuk parameter yang bisa lebih dari satu. simpan di array $parameter_data
				$postlength = count($_POST);
				if ($postlength > 5) {
					$repetisi = ($postlength-5)/5;
					for ($i=1; $i<=$repetisi ; $i++) { 				
						$parameter_data = array(
							'parameter_id'			=> '',
							'API_id'				=> "$API_id",
							'parameter_name'		=> $_POST['name'.$i],
							'parameter_description'	=> $_POST['description'.$i],
							'parameter_format'		=> $_POST['format'.$i],
							'parameter_default'		=> $_POST['default'.$i],
							'parameter_mandatory'	=> $_POST['mandatory'.$i]
						);
						$this->API_model->insert_new_entry_parameter($parameter_data);
					}
				}
				redirect(base_url()."API_admin/index/API/$API_id/");
				
			} else {
				// jika bukan admin maupun sudah login
				$this->redirect_error_page();

			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();

		}
		
	}

	public function display_navigation_bar()
	{
		//load file model 
		$this->load->model('navigation_bar_model');

		// ambil 
		$data['query_navigation'] = $this->navigation_bar_model->get_category();

		// Menampilkan side navigation bar
		$this->load->view('CMS/navigation_baru_admin',$data); 

	}

	public function new_content()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		
		// checking session
		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin
				//proses tampilan CMS dll
				//load library, model, helper
				$this->load->library('ckeditor');

				//atur konfigurasi dari ckeditor yang dimiliki
				$this->ckeditor->basePath = base_url().'asset/js/ckeditor/';
				$this->ckeditor->config['toolbar'] = array(
		                array( 'Source', '-', 'Bold', 'Italic', 'Underline', '-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','Image' ,'Heading')
		                                                    );
				$this->ckeditor->config['language'] = 'it';
				$this->ckeditor->config['width'] = '730px';
				$this->ckeditor->config['height'] = '300px';   

				//tampilkan view
				$this->display_header();
				$this->display_navigation_bar();
				$this->load->view('CMS/add_new_entry_view_content');
			} else {
				// jika bukan admin maupun sudah login
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}

	public function insert_content()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		
		// checking session
		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
		
				// jika pengguna sudah login dan role nya admin
				//proses insert content ke database
				//load model
				$this->load->model('API_model');
				
				//ambil data-data dari post dan tabel yang sudah ada
				$name = $_POST['name']; $description = $_POST['deskripsi'];
				$rank =  $this->API_model->get_last_category_rank() + 1;

				//buat array untuk input data ke tabel kategori
				$content_data = array(
					'category_id'				=> '',
					'category_name'				=> "$name",
					'category_rank'				=> "$rank",
					'category_type'				=> "content",
					'category_content'			=> "$description",
					'category_active_status'	=> '1',
				);
				$category_id = $this->API_model->insert_new_entry_content($content_data);

				//redirect kepada halaman yang baru dibuat (harusnya, tapi belom)
				redirect(base_url()."API_admin/index/category/$category_id");
			} else {
				// jika bukan admin maupun sudah login
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
			

	}
}