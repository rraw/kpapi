<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class API_admin extends CI_Controller {
	public function index($type = NULL, $id = NULL)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		
		if ($type == NULL && $id == NULL) {
			# code...
			$this->load->model('content_model');
			$type = "category";
			$temp = $this->content_model->get_first_rank_category_cms();
			$id = $temp[0]->category_id;
		}
		// checking session
		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				//Menampilkan header
				$this->display_header();

				//menampilkan navigation bar
				$this->display_navigation_bar();

				//menampilkan konten
				$this->display_content($id, $type);

				// menampilkan footer
				$this->display_footer();
			} else
			{
				$this->log_out();
				$this->redirect_error_page();
			}

		} else 
		{
			$this->log_out();
			$this->redirect_error_page();
		}
	
	}

	// session function
	public function retrieve_session()
	{
		$data = $this->session->all_userdata();
		return $data;
	}

	function log_out()
	{
		$this->load->library('session');
		$this->session->sess_destroy();
	}

	public function redirect_error_page()
	{
		redirect("http://localhost/kpAPI/login/forbidden_access");
	}


	public function display_header()
	{	
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$this->load->library('session');
				$data = $this->retrieve_session();
				$name['username'] = $data['username'];
				$this->load->view('CMS/header_cms',$name);  
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}	
	}

	public function display_navigation_bar()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				//load file model 
				$this->load->model('navigation_bar_model');
				// ambil 
				$data['query_navigation'] = $this->navigation_bar_model->get_active_n_inactive_category();
				// Menampilkan side navigation bar
				$this->load->view('CMS/navigation_baru_admin',$data); 
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}

	}

	public function display_content($id = NULL, $type = NULL)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				if ($type == "API") 
				{
					// Jika tipe null, defaultnya API
					if ($id === NULL) {
							$this->load->view('main_content');
						}
						else
						{	
							$this->display_apicontent($id);
						}
				} else
				{
					// jika tipenya kategori
						if ($id === NULL) {
							# code...
							$this->load->view('main_content');
						}
						else
						{	
							$this->display_category_content($id);
						}
				}
			} else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}

	public function display_footer()
	{
		$this->load->view('footer');
	}

	public function display_category_content($category_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$this->load->model('content_model');

				$this->content_model->load_database();

				$data['content'] = $this->content_model->get_category_content($category_id);

				$this->load->view('CMS/category_content_admin_view',$data);
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	
	}

	public function display_apicontent($api_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{

				$this->load->model('content_model');

				// Load Database
				$this->content_model->load_database();


				//variabel id API yang ingin ditampilkan
				$data['token'] = $this->session->userdata('token');
				$data['query_deskripsi'] = $this->content_model->get_description($api_id);

				$data['query_parameter'] = $this->content_model->get_parameter($api_id);
		  

				// Menampilkan konten web berupa deskripsi API
				$this->load->view('CMS/api_content_admin_view',$data);
			} else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}

	//update2an
	public function update_entry($api_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin
				//load API model dan ckeditro
				$this->load->library('ckeditor');
				$this->load->model('API_model');

				//atur konfigurasi dari ckeditor yang dimiliki
				$this->ckeditor->basePath = base_url().'asset/js/ckeditor/';
				$this->ckeditor->config['toolbar'] = array(
		                array( 'Source', '-', 'Bold', 'Italic', 'Underline', '-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','-','Image' )
		                                                    );
				$this->ckeditor->config['extraPlugins'] = 'image';
				$this->ckeditor->config['language'] = 'en';
				$this->ckeditor->config['width'] = '730px';
				$this->ckeditor->config['height'] = '300px';

				//query untuk mengambil data2 penting
				$data['API'] = $this->API_model->get_API($api_id);
				$data['parameter'] = $this->API_model->get_parameter($api_id);
				$data['query'] = $this->API_model->get_all_api_category();

				//load view dengan $data
				$this->display_header();
				$this->display_navigation_bar();
				$this->load->view('CMS/update_entry_view_API', $data);
				
			} else {
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
		
	}

	public function update_data()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin
				//load model
				$this->load->model('API_model');
				
				//ambil data-data dari post
				$category = $_POST['category']; $newcategory = $_POST['newcategory']; $category_desc = $_POST['deskripsikategori'];
				$name = $_POST['name']; $description = $_POST['deskripsi']; $API_id = $_POST['API_id']; $input = $_POST['input'];

				
				//SEQUENCE UPDATE CATEGORY
				//kalo category baru, masukin ke tabel category dulu, trus IDnya masukin ke $category
				if ($newcategory != '') {
					$rank =  $this->API_model->get_last_category_rank() + 1;
					$category_data = array(
						'category_name' 	=> "$newcategory",
						'category_rank'		=> "$rank",
						'category_type' 	=> 'API',
						'category_content'	=> "$category_desc"
					);
					$category =  $this->API_model->insert_new_entry_category($category_data);
				}
				
				//SEQUENCE UPDATE API
				//buat array untuk input data ke tabel API dan input sekalian
				$api_data = array(
					'API_id'			=> "$API_id",
					'API_name'			=> "$name",
					'API_description'	=> "$description",
					'API_input'			=> "$input",
					'category_id'		=> "$category"
				);
				$this->API_model->update_entry_API($api_data);
			

				//SEQUENCE UPDATE PARAMETER
				//delete parameter2 yang lama dari API bersangkutan
				$this->API_model->delete_entry_parameter($API_id);

				//siapkan repetisi untuk parameter yang bisa lebih dari satu. simpan di array $parameter_data
				$postlength = count($_POST);
				if ($postlength > 5) 
				{

					//insert tupel baru
					$repetisi = ($postlength-5)/5;
					$j = 1;
					for ($i=1; $i<=$repetisi ; $i++) 
					{
						while(!array_key_exists('name'.$j, $_POST))
						{
							$j++;
						}
						
						$parameter_data = array(
							'API_id'				=> "$API_id",
							'parameter_name'		=> $_POST['name'.$j],
							'parameter_description'	=> $_POST['description'.$j],
							'parameter_format'		=> $_POST['format'.$j],
							'parameter_default'		=> $_POST['default'.$j],
							'parameter_mandatory'	=> $_POST['mandatory'.$j]
						);
						$j++;
						$this->API_model->insert_new_entry_parameter($parameter_data);
					}
				}
				redirect(base_url()."API_admin/index/API/$API_id/");
				
			} else {
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();		
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();

		}

		
	}

	public function update_content($id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin
				//load API model dan ckeditro
				$this->load->library('ckeditor');
				$this->load->model('content_model');

				//atur konfigurasi dari ckeditor yang dimiliki
				$this->ckeditor->basePath = base_url().'asset/js/ckeditor/';
				$this->ckeditor->config['toolbar'] = array(
		                array( 'Source', '-', 'Bold', 'Italic', 'Underline', '-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList','-','Image','MediaEmbed' )
		                                                    );
				$this->ckeditor->config['extraPlugins'] = 'mediaembed';
				$this->ckeditor->config['extraPlugins'] = 'image';
				$this->ckeditor->config['language'] = 'en';
				$this->ckeditor->config['width'] = '730px';
				$this->ckeditor->config['height'] = '300px';

				//query untuk mengambil data2 penting
				$data['content'] = $this->content_model->get_category_content($id);

				//load view dengan $data
				$this->display_header();
				$this->display_navigation_bar();
				$this->load->view('CMS/update_entry_view_content', $data);
				
			} else {
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}

		
	}

	public function update_content_data()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				// jika pengguna sudah login dan role nya admin
				
				//load model
				$this->load->model('content_model');

				//ambil data2 dari post
				$name = $_POST['name']; $content = $_POST['deskripsi']; $category_id = $_POST['category_id'];

				//SEQUENCE UPDATE content
				//buat array untuk input data ke tabel API dan input sekalian
				$content_data = array(
					'category_id'		=> "$category_id",
					'category_name'		=> "$name",
					'category_content'	=> "$content",
				);
				$this->content_model->update_entry_content($content_data);

				//kembali ke halaman awal
				redirect(base_url()."API_admin/index/category/$category_id/");
			} else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();$this->log_out();
			};
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		};
	}

	//delete2an
	public function delete_api($api_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$this->load->model('API_model');

				//hapus parameter, cek kategori apakah masih ada kawannya lalu delete, trus API 
				$this->API_model->delete_entry_parameter($api_id);

				$this->API_model->delete_entry_API($api_id);
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();$this->log_out();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}

	public function delete_content($id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				//load model
				$this->load->model('API_model');
			
				//delete konten
				$this->API_model->delete_entry_category($id);
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}

	public function delete_category($category_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$this->delete_content($category_id);
				$this->API_model->delete_entry_API_by_category_id($category_id);
			} else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}	

	public function update_api_status()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$status = $_POST['status'];
				$api_id = $_POST['api_id'];
				
				if ($status == 1) {
					echo "You have activate this content";
				} else {
					echo "You have deactiveate this content";
				}


				$this->load->model('API_model');
				// $this->API_model->update_active_status($api_id, $status);
				$this->API_model->update_api_active_status($api_id, $status);
			} else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}

	public function update_category_status()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$active_status = $_POST['status'];
				$category_id = $_POST['category_id'];
				
				if ($active_status == 1) {
					echo "You have activate this content";
				} else {
					echo "You have deactiveate this content";
				}

				$this->load->model('API_model');
				// $this->API_model->update_active_status($api_id, $status);
				$this->API_model->update_category_active_status($category_id, $active_status);
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();	
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();		
		}
	}
	
	public function edit_rank()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				//load model
				$this->load->model('navigation_bar_model');
				$data['category'] = $this->navigation_bar_model->get_category();
				//load database
				$this->load->view('cms/edit_rank_view', $data);
			} else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}

	public function submit_rank()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 	
		{
			$logged_in	= $data['logged_in'];
			$role		= $data['role'];

			if ($logged_in && ($role =='admin')) 
			{
				$this->load->model('content_model');

				foreach ($_POST as $key => $value){
					$kunci = explode("t", $key);
					// echo $kunci['1'];
					$this->content_model->update_rank($kunci['1'], $value);
				}
				redirect(base_url()."API_admin/");
			}else 
			{
				// jika bukan admin maupun sudah login
				$this->log_out();
				$this->redirect_error_page();
			}
		}else 
		{
			// jika session belum di set
			$this->log_out();
			$this->redirect_error_page();
		}
	}


}