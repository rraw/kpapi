<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class API extends CI_Controller {

	public function index()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		

		$this->load->model('content_model');
		$type = "category";
		$temp = $this->content_model->get_first_rank_category();
		$id = $temp[0]->category_id;

		if (isset($data['logged_in'])) {

			$logged_in = $data['logged_in'];

			if ($logged_in ) {
				$username['username'] = $data['username'];
				//Menampilkan header
				$this->display_header($username);
				//menampilkan navigation bar
				$this->display_navigation_bar();
				//menampilkan konten
				$this->display_content($id);
				$this->display_footer();# code..
			} else
			{
				redirect("http://localhost/kpAPI/login");
				// echo "sorry, you have to login first";
			}
			
		} else {
			redirect("http://localhost/kpAPI/login");
			// echo "sorry, you have to login first";
		}
	}

	// session session an
	public function retrieve_session()
	{
		$data = $this->session->all_userdata();
		return $data;
	}

	public function check_session()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();	
		if (isset($data['logged_in'])) 
		{
			$logged_in = $data['logged_in'];
			if ($logged_in ) 
			{
				echo TRUE;
			} else
			{
				// not logged in
				echo FALSE;
			}
		} else
		{
			echo FALSE;
		}
	}

	public function log_out()
	{
		$this->load->library('session');
		$this->session->sess_destroy();
	}

	public function redirect_error_page()
	{
		redirect("http://localhost/kpAPI/login/forbidden_access");
	}


	public function display_header($username)
	{
		$this->load->view('header',$username);  	
	}

	public function display_navigation_bar()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		if (isset($data['logged_in'])) 
		{
			$logged_in = $data['logged_in'];
			if ($logged_in) 
			{
				//load file model 
				$this->load->model('navigation_bar_model');
				// ambil 
				$data['query_navigation'] = $this->navigation_bar_model->get_active_category();
				// Menampilkan side navigation bar
				$this->load->view('navigation_baru',$data); 
			} else 
			{
				// user belum log in
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}

	public function display_content($id = NULL)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		if (isset($data['logged_in'])) 
		{
			$logged_in = $data['logged_in'];
			if ($logged_in) 
			{
				$this->display_category_content($id);
		} else 
			{
				// user belum log in
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}

	}

	public function display_footer()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		if (isset($data['logged_in'])) 
		{
			$logged_in = $data['logged_in'];
			if ($logged_in) 
			{
				$this->load->view('footer');
		} else 
			{
				// user belum log in
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}

	public function display_apicontent($api_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();

		if (isset($data['logged_in'])) 
		{
			$logged_in = $data['logged_in'];
			if ($logged_in ) 
			{
				$this->load->model('content_model');

				// Load Database
				$this->content_model->load_database();

				//variabel id API yang ingin ditampilkan
				$this->load->library('session');

				$data['token'] = $this->session->userdata('token');

				$data['query_deskripsi'] = $this->content_model->get_active_api_description($api_id);

				$data['query_parameter'] = $this->content_model->get_parameter($api_id);
		  
				// Menampilkan konten web berupa deskripsi API
				$this->load->view('api_content',$data);
			} else 
			{
				// user belum log in
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}

	public function display_category_content($category_id)
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		if (isset($data['logged_in'])) 
		{

			$logged_in = $data['logged_in'];

			if ($logged_in ) 
			{
				$this->load->model('content_model');

				$this->content_model->load_database();

				$data['content'] = $this->content_model->get_category_content($category_id);

				$this->load->view('category_content_view',$data);
			} else 
				{
					// user belum log in
					$this->redirect_error_page();
				}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}

	// BUAT PARAMETER SUBMISSION
	public function parameter_form()
	{
		$this->load->library('session');
		$data = $this->retrieve_session();
		if (isset($data['logged_in'])) 
		{

			$logged_in = $data['logged_in'];

			if ($logged_in) 
			{

				// 
				$output_type ="";

				$url="";
				//ngambil semua variabel post
				foreach ($_POST as $key => $value){
					
					if ("{$key}"=="input_url"){

						$url = "{$value}";

					} else {
						if ("{$key}"=="output") 
						{
							# code...
						$output_type = "{$value}";
						}
						$url = $url . "{$key}={$value}&";	
					} //end if
				}
				
				echo "<h3>Input Link</h3>";
				echo "<p>Example</p>";
				echo "<code>";
				echo "<a href=\"";
				print $url;
				echo "\">";
				print $url;
				echo "</a>";
				echo "</code>";
				
				//KONTEN OUTPUT
				echo "<h3>Output</h3>";
				if ($output_type == "json") 
				{
					// untuk output bertipe json
					echo "<textarea id ='output_json' style='overflow:scroll;margin-bottom:30px;'>";
				} else
				{
					// untuk output selain json
					echo "<code style='overflow:scroll;margin-bottom:30px;'>";
					echo "<xmp>";
				}

				//curl
				$handle=curl_init($url);
				curl_setopt($handle, CURLOPT_VERBOSE, true);
				curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
				$content = curl_exec($handle);
				
				//echo isi dari http requestnya
				echo $content;
				
				if ($output_type == "json") 
				{
					# code...
					echo "</textarea>";
				} else
				{
					echo "</xmp>";
					echo "</code>";
				}

			} else 
			{
				// user belum log in
				$this->redirect_error_page();
			}
		} else 
		{
			// jika session belum di set
			$this->redirect_error_page();
		}
	}
}