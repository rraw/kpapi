<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/
class Login extends CI_Controller
{
	
	function index()
	{
		$this->load->library('session');
		$data= $this->session->all_userdata();
		if (isset($data['logged_in'])) 
		{
			// jika sudah pernah login
			$logged_in 	= $data['logged_in'];
			$role		= $data['role'];
			if ($logged_in) {

				// Pengguna masih log in
				if ($role == 'admin') {
					// admin
					redirect("http://localhost/kpAPI/API_admin");
				} else 
				{
					// common user
					redirect("http://localhost/kpAPI/");
				}


			} else
			{
				$this->display_login_page();
			}

		} else
		{
			$this->display_login_page();
		}
	}

	function display_login_page()
	{
		$this->load->view('login_page_view');
	}

	function authentication()
	{
		$this->load->library('session');
		$data['username']=$_POST['username'];
		$data['password']=$_POST['password'];
		// load model

		$this->load->model('login_model');
		$result= $this->login_model->get_username_password($data);

		$count = count($result);

		if ($count > 0) 
		{	
			// login berhasil

			// configure session
			foreach ($result as $key ) {
				# code...
				$this->session->set_userdata('username',$key->username);
				$this->session->set_userdata('token', $key->token);
				$this->session->set_userdata('role', $key->role);
				$this->session->set_userdata('logged_in',TRUE);
			}
			
			$data = NULL;
			$data['role'] = $this->session->userdata['role'];
			$data['logged_in'] = $this->session->userdata['logged_in'];
			echo json_encode($data);


		} else {
			// send false data
			$data = NULL;
			$data['role'] = 'none';
			$data['logged_in'] = FALSE;
			echo json_encode($data);
		}

	}
	
	function log_out()
	{
		$this->load->library('session');
		$this->session->sess_destroy();
		echo "false";
	}

	function forbidden_access()
	{
		$this->load->view('error_message');
	}



}
?>