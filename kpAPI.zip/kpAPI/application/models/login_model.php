<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/

class Login_model extends CI_Model
{
	function get_username_password($data = null)
	{
		$username = $data['username'];
		$password = $data['password'];
		$query = "SELECT username,password,role,token FROM member_account LEFT JOIN member_token ON member_account.member_id = member_token.member_id WHERE username ='".$username."' AND password ='".$password."'";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}
}

?>