
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class navigation_bar_model extends CI_Model 
{

	function get_category()
	{
		$q = $this->db->query('SELECT * FROM category WHERE category_active_status >=0 ORDER BY category_rank');
		return $q->result();
	}

	function get_active_category()
	{
		$q = $this->db->query("SELECT * FROM category WHERE category_active_status='1' ORDER BY category_rank");
		return $q->result();
	}

	function get_active_n_inactive_category()
	{
		$q = $this->db->query("SELECT * FROM category WHERE category_active_status>= 0 ORDER BY category_rank");
		return $q->result();
	}

	function get_active_api_by_categoryid_sort_by_name($category_id)
	{
		$query = "SELECT * FROM api WHERE api_active_status=1 AND category_id="."'".$category_id."' ORDER BY api_name";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_api_by_categoryid_sort_by_name($category_id)
	{
		$query = "SELECT * FROM api WHERE api_active_status>=0 AND category_id="."'".$category_id."' ORDER BY api_name";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_api_by_categoryid($category_id)
	{
		$query = "SELECT * FROM api WHERE category_id="."'".$category_id."'";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_categoryid_by_apiid($api_id)
	{
		$query = "SELECT category_id FROM api WHERE api_id=".$api_id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

}