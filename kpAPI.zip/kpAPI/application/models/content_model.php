<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Content_model extends CI_Model 
{

	// GET FROM DATABASE

	function load_database()
	{
		$this->load->database();
	}

	function get_active_api_description($id)
	{
		$query = "SELECT * FROM API WHERE API_id =".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_description($id)
	{
		//API ID
		$query = "SELECT * FROM API WHERE API_id =".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_parameter($id)
	{
		$query = "SELECT * FROM parameter WHERE API_id=".$id." AND parameter_active_status = 1";
		$query_result = $this->db->query($query);
		return $query_result->result();

	}

	function get_category_content($category_id)
	{
		$query = "SELECT category_active_status,category_content,category_name,category_id,category_type FROM category WHERE category_id =".$category_id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function update_entry_content($data){
		$this->db->where('category_id',$data['category_id']);
		$this->db->update('category',$data);
	}

	function update_rank($id, $rank)
	{
		$query = "UPDATE category SET category_rank = '". $rank."' WHERE category_id='". $id . "'";
		$query_result = $this->db->query($query);
	}

	function get_first_rank_category_cms()
	{
		$query_ = "SELECT min(category_rank) AS rank FROM category WHERE category_active_status >= 0";
		$rank = $this->db->query($query_);
		$arrQuery = $rank->result_array(); 
		$query = "SELECT category_id FROM category WHERE category_rank = ".$arrQuery[0]['rank']." AND category_active_status >= 0  ";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_first_rank_category()
	{
		$query_ = "SELECT min(category_rank) AS rank FROM category WHERE category_active_status = 1";
		$rank = $this->db->query($query_);
		$arrQuery = $rank->result_array(); 
		$query = "SELECT category_id FROM category WHERE category_rank = ".$arrQuery[0]['rank']." AND category_active_status = 1  ";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

}
