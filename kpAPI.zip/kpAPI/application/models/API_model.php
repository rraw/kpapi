<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class API_Model extends CI_Model {

	//get ALL-an
	function get_all_API(){
		$this->load->database();
		$query = $this->db->get('API');
		return $query->result();
	}

	function get_all_category(){
		$this->load->database();
		$query = $this->db->query("SELECT * FROM category WHERE category_type='category'");
		return $query->result();
	}

	//insert2an baru
	function insert_new_entry_API($api_data){
		$this->db->insert('api',$api_data);
		return $this->db->insert_ID();
	}

	function get_last_category_rank(){
		$maxid = 0;
		$row = $this->db->query('SELECT MAX(category_rank) AS `maxid` FROM `category`')->row();
		if ($row) {
    		$maxid = $row->maxid; 
		}
		return $maxid;
	}

	function insert_new_entry_content($content_data){
		$this->db->insert('category',$content_data);
		return $this->db->insert_ID();
	}

	function insert_new_entry_category($data){
		$this->db->insert('category',$data);
		return $this->db->insert_ID();
	}

	function insert_new_entry_parameter($parameter_data){
		$this->db->insert('parameter',$parameter_data);
		return $this->db->insert_ID();
	}

	//update2an baru
	function update_entry_API($api_data){
		$this->db->where('API_id',$api_data['API_id']);
		$this->db->update('api',$api_data);
	}

	function update_entry_parameter($parameter_data){
		$this->db->where('parameter_id',$parameter_data['parameter_id']);
		$this->db->update('parameter',$parameter_data);	
	}

	// Update status API
	function update_api_active_status($api_id, $active_status){
	$query = "UPDATE api SET api_active_status='" . $active_status. "' WHERE API_id='" . $api_id . "'";
	$query_result = $this->db->query($query);
	
	}

	// Update status category
	function update_category_active_status($category_id, $active_status){
	$query = "UPDATE category SET category_active_status='" . $active_status. "' WHERE category_id='" . $category_id . "'";
	$query_result = $this->db->query($query);
	}

	// Delete versi baru, update active_status jadi -127
	function delete_entry_category($category_id)
	{
		$query = "UPDATE category SET category_active_status='-127' WHERE category_id='" . $category_id . "'";
		$query_result = $this->db->query($query);
	}

	function delete_entry_API($api_id)
	{
		$query = "UPDATE api SET api_active_status='-127' WHERE API_id='" . $api_id . "'";
		$query_result = $this->db->query($query);
	}

	function delete_entry_API_by_category_id($category_id)
	{
		$query = "UPDATE api SET api_active_status='-127' WHERE category_id='" . $category_id . "'";
		$query_result = $this->db->query($query);
	
	}

	function delete_entry_parameter($api_id){
		$query = "UPDATE parameter SET parameter_active_status='-127' WHERE api_id='" . $api_id . "'";
		$query_result = $this->db->query($query);
	}


	//delete2an yang lama, ga dipake
	function delete_entry_parameter_old($api_id){
		$this->db->where('api_id',$api_id);
		$this->db->delete('parameter');
	}

	function delete_entry_category_old($category_id){
		$this->db->where('category_id',$category_id);
		$this->db->delete('category');
	}

	function delete_entry_API_old($api_id){
		$this->db->where('api_id',$api_id);
		$this->db->delete('api');
	}

	//ambil API, category, dan parameter yang spesifik
	function get_API($id){
		$query = "SELECT * FROM API INNER JOIN category ON api.category_id=category.category_id WHERE API_id =".$id;
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_parameter($id){
		$query = "SELECT * FROM parameter WHERE API_id=".$id." AND parameter_active_status =1";
		$query_result = $this->db->query($query);
		return $query_result->result();

	}

	function get_category($id){
		$query = "SELECT category_id FROM api WHERE API_id=".$id." AND api_active_status >= 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}

	function get_all_api_category()
	{
		$query = "SELECT category_name,category_id FROM category WHERE category_type='category' AND category_active_status >= 0";
		$query_result = $this->db->query($query);
		return $query_result->result();
	}



}