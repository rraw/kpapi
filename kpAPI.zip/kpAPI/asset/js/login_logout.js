$(document).ready(function() 
{
	$(".log-out").click(function(){
		

		if (confirm("Are you sure?")) 
		{
			$.post("http://localhost/kpAPI/index.php/login/log_out/",
				{
					
				},
				function(data){
					alert("Log out succeed");
					window.location.replace("http://localhost/kpAPI/login");
				});

		};

	});

	$("#home").click(function(){
		window.location.replace("http://localhost/kpAPI/");
		// body...
	});

});