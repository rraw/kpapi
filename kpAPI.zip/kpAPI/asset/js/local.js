
$(document).ready(function() 
{
    var intId = $("#parameter-table div").length + 1;
    $("#add").click(function() 
    {  
        var row_begin =$("<tr>")
        var fieldWrapper = $("<div class=\"fieldwrapper\" id=\"field" + intId + "\"/>");
        var fName = $("<td><input type=\"text\" class=\"fieldname\" name=\"name" + intId + "\"/></td>");
        var fDescription = $("<td><textarea class=\"fielddescription\" name=\"description" + intId + "\"/></td>");
        // var fDescription = $("<td><input type=\"text\" class=\"fielddescription\" name=\"description" + intId + "\"/></td>");
        var fFormat = $("<td><input type=\"text\" class=\"fieldformat\" name=\"format" + intId + "\"/></td>");
        var fDefault = $("<td><input type=\"text\" class=\"fielddefault\" name=\"default" + intId + "\"/></td>");
        var fMandatory = $("<td><select class=\"fieldmandatory\" name=\"mandatory" + intId + "\"><option value=\"TRUE\">TRUE</option><option value=\"FALSE\">FALSE</option></select></button></td>");
        var removeButton = $("<td class=\"invincible\"><button type=\"button\" class=\"delete-button\" value=\"Delete\">X</button></td>");
        var row_end =$("</tr>")
        
        removeButton.click(function() {
            $(this).parent().remove();
        });

        row_begin.append(fName);
        row_begin.append(row_begin);
        row_begin.append(fDescription);
        row_begin.append(fFormat);
        row_begin.append(fDefault);
        row_begin.append(fMandatory);
        row_begin.append(removeButton);
        row_begin.append(row_end);
        $("#parameter-table").append(row_begin);
        

        intId++;
    });
    
    $(".delete-button").click(function() 
    {
        $(this).parent().parent().remove();
    });
    
    $('select[name=category]').change(function () 
    {
        if ($(this).val() == '-1') 
        {
            $('#newcategory').show();
            $('#category_desc').show();
        } 
        else 
        {
            $('#newcategory').hide();
            $('#category_desc').hide();
        }
    });

    
});
