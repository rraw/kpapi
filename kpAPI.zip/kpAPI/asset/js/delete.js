$(document).ready(function() {

    $("#deleteAPI").click(function()
    {
    	var API_id = $("#API_id").val();
    	var API_name = $("#API_name").val();
      	if(confirm("You're going to delete " + API_name + ". Are you sure?"))
		{
    		$.post("http://localhost/kpAPI/API_admin/delete_api/" + API_id, function(data)
    		{
    			alert(API_name + " deleted.");
    			window.location.replace("http://localhost/kpAPI/API_admin");
    		});
		}
		else
		{
    		//do nothing
		}
    });

    $("#deletecontent").click(function()
    {
        var category_id = $("#category_id").val();
        var category_name = $("#category_name").val();
        if(confirm("You're going to delete " + category_name + " content. Are you sure?"))
        {
            $.post("http://localhost/kpAPI/index.php/API_admin/delete_content/" + category_id, function(data)
            {
                alert(category_name + " deleted.");
                window.location.replace("http://localhost/kpAPI/API_admin");
            });
        }
        else
        {
            //do nothing
        }
    });

    $("#deletecategory").click(function(){
        var category_id = $("#category_id").val();
        var category_name = $("#category_name").val();
        // alert("delete category??")

        if(confirm("Deleting category " + category_name + " will erase all of its API. Proceed? "))
        {
            $.post("http://localhost/kpAPI/index.php/API_admin/delete_category/" + category_id, function(data)
            {
                alert(category_name + " deleted.");
                window.location.replace("http://localhost/kpAPI/API_admin");
            });
        }
        else
        {
            //do nothing
        }
    });

});