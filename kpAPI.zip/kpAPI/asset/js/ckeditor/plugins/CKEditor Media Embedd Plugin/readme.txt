This plugin is based on http://www.fluidbyte.net/embed-youtube-vimeo-etc-into-ckeditor.
Rewritten by Fabian Vogelsteller [frozeman.de]

Installing the MediaEmbed Plugin

1. Copy the "mediaembed" folder and place it in the ~/ckeditor/plugins directory.

2. Enable the plugin by changing or adding the extraPlugins line in your configuration (config.js):

    config.extraPlugins = 'mediaembed';

3. Add the button to your toolbar by adding the 'MediaEmbed' item to the toolbar list.
(See http://docs.cksource.com/CKEditor_3.x/Developers_Guide/Toolbar)

That's it, overall pretty simple.  This plugin could also be used for inserting custom code snippets, or pretty much anything that requires a custom insert.  Enjoy!
