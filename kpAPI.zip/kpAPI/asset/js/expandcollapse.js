$(document).ready(function(){
	
	$(".sub-btn").hide();
	$(".toggle_container").hide();

	$("div.trigger").toggle(function(){
		$(this).addClass("active"); 
		}, function () {
		$(this).removeClass("active");
	});

	$(".trigger-span").toggle(function(){
		$(this).addClass("active-span"); 
		}, function () {
		$(this).removeClass("active-span");
	});

	$(".trigger-span").click(function(){
		$(this).parent().next(".toggle_container").slideToggle("slow,");
	});

	// click function trigger
	$("div.trigger.a a").click(function()
	{
		var id = this.id;
		$.post("http://localhost/kpAPI/index.php/API/check_session/",function(data)
        {
            if (data) 
            {
                // logged in
                $('#API-content').
        		load('http://localhost/kpAPI/index.php/API/display_category_content/'+ id);
       
            } else
            {
            	// not logged in
                alert("Please Log In to Continue");
                window.location.replace("http://localhost/kpAPI/");
            };
        });    
	});
	
	$("div.trigger.b a").click(function()
	{
		var id = this.id;
		$.post("http://localhost/kpAPI/index.php/API/check_session/",function(data)
        {
            if (data) 
            {
                // logged in
                $('#API-content').
       			load('http://localhost/kpAPI/index.php/API_admin/display_category_content/'+ id);
            } else
            {
                alert("Please Log In to Continue");
                window.location.replace("http://localhost/kpAPI/");
            };
        });
	});

	$(".button-group#add-content").hover(
		function()
		{
    		$(".sub-btn").slideToggle("fast");
    	}
		,function()
		{
			$(".sub-btn").slideToggle("fast");
		}
	);

	//untuk manggil edit rank
    $("#edit_rank_button").click(function()
    {
        $.post("http://localhost/kpAPI/index.php/API/check_session/",function(data)
        {
            if (data) 
            {
                // logged in
                $('#API-content').
                load('http://localhost/kpAPI/index.php/API_admin/edit_rank/');
            } else
            {
                // not logged in
                alert("Please Log In to Continue");
                window.location.replace("http://localhost/kpAPI/");
            };
        });
    });	

});